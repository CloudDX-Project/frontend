import { useRef, useState } from 'react'
import {
  ArrowDownRight,
  ArrowRight,
  CalendarDays,
  Check,
  ChevronDown,
  ChevronRight,
  CircleDollarSign,
  Clock3,
  Compass,
  Copy,
  Hotel,
  Luggage,
  MapPin,
  Menu,
  Minus,
  MoreHorizontal,
  Navigation,
  Plane,
  Plus,
  Search,
  Sparkles,
  Star,
  Ticket,
  TrainFront,
  Umbrella,
  UsersRound,
  X,
} from 'lucide-react'
import { createTripPlan, type TravelPace } from './services/plannerApi'

type Interest = '미식' | '자연' | '카페' | '문화' | '휴식' | '액티비티'

const interests: { label: Interest; icon: string }[] = [
  { label: '미식', icon: '✦' },
  { label: '자연', icon: '⌁' },
  { label: '카페', icon: '◌' },
  { label: '문화', icon: '◐' },
  { label: '휴식', icon: '☁' },
  { label: '액티비티', icon: '↗' },
]

const destinations = [
  {
    city: 'Jeju, Korea',
    title: '제주',
    image: 'https://images.unsplash.com/photo-1578885070438-7b5782e2c7a4?auto=format&fit=crop&w=1200&q=85',
    description: '바다와 숲, 느린 쉼이 공존하는 섬',
    tag: '가장 많이 저장한 곳',
  },
  {
    city: 'Fukuoka, Japan',
    title: '후쿠오카',
    image: 'https://images.unsplash.com/photo-1601042879364-f3947d3f9c16?auto=format&fit=crop&w=1200&q=85',
    description: '맛있는 도시 산책의 정석',
    tag: '주말 2박 3일',
  },
  {
    city: 'Gangneung, Korea',
    title: '강릉',
    image: 'https://images.unsplash.com/photo-1591302418462-eb55463b49d6?auto=format&fit=crop&w=1200&q=85',
    description: '파도 소리와 커피 향을 따라',
    tag: 'KTX로 가볍게',
  },
]

const schedule = [
  [
    { time: '11:10', type: 'arrival', title: '제주공항 도착', description: '렌터카 인수 후 애월로 출발', duration: '이동 35분' },
    { time: '12:20', type: 'food', title: '애월 바다 식당', description: '제철 해산물로 시작하는 첫 식사', duration: '머무름 70분' },
    { time: '14:10', type: 'spot', title: '한담 해안산책로', description: '숙소 체크인 전, 느긋한 바다 산책', duration: '머무름 90분' },
    { time: '17:30', type: 'stay', title: '스테이 애월 체크인', description: '노을이 보이는 객실에서 잠깐의 휴식', duration: '도보 4분' },
  ],
  [
    { time: '09:30', type: 'spot', title: '비자림 아침 산책', description: '사람이 적은 시간의 숲길', duration: '이동 48분' },
    { time: '12:10', type: 'food', title: '성산 로컬 브런치', description: '제주 식재료로 만든 가벼운 한 끼', duration: '머무름 75분' },
    { time: '14:30', type: 'ticket', title: '섭지코지 & 해안 드라이브', description: '풍경 좋은 길을 중심으로 동선 최적화', duration: '머무름 130분' },
    { time: '19:00', type: 'food', title: '동문시장 야간 미식', description: '저녁은 취향대로 골라 즐기기', duration: '이동 45분' },
  ],
  [
    { time: '10:00', type: 'spot', title: '오설록 티 뮤지엄', description: '공항으로 가기 전, 여유 있는 마지막 코스', duration: '이동 42분' },
    { time: '13:20', type: 'food', title: '공항 근처 고기국수', description: '출발 전 제주다운 한 그릇', duration: '이동 28분' },
    { time: '15:00', type: 'arrival', title: '제주공항 출발', description: '렌터카 반납 및 탑승 수속', duration: '여행 마무리' },
  ],
]

const iconForType = (type: string) => {
  if (type === 'food') return <span>✦</span>
  if (type === 'stay') return <Hotel size={16} />
  if (type === 'ticket') return <Ticket size={16} />
  if (type === 'arrival') return <Plane size={16} />
  return <MapPin size={16} />
}

function App() {
  const [prompt, setPrompt] = useState('친구 2명과 9월 제주 2박 3일, 바다와 맛집을 충분히 즐기고 싶어요')
  const [selectedInterests, setSelectedInterests] = useState<Interest[]>(['미식', '자연', '휴식'])
  const [travelers, setTravelers] = useState(3)
  const [pace, setPace] = useState<TravelPace>('BALANCED')
  const [isPlanning, setIsPlanning] = useState(false)
  const [hasPlan, setHasPlan] = useState(false)
  const [activeDay, setActiveDay] = useState(0)
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [toast, setToast] = useState('')
  const resultRef = useRef<HTMLElement>(null)

  const showToast = (message: string) => {
    setToast(message)
    window.setTimeout(() => setToast(''), 2600)
  }

  const toggleInterest = (interest: Interest) => {
    setSelectedInterests((current) =>
      current.includes(interest) ? current.filter((item) => item !== interest) : [...current, interest].slice(0, 3),
    )
  }

  const createPlan = async () => {
    setIsPlanning(true)
    try {
      await createTripPlan({
        prompt,
        destination: '제주',
        startDate: '2026-09-11',
        endDate: '2026-09-13',
        travelers,
        interests: selectedInterests,
        pace,
        budgetPerPerson: 543000,
      })
      setHasPlan(true)
      window.setTimeout(() => resultRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 50)
      showToast('맞춤 여행 플랜을 완성했어요.')
    } catch (error) {
      showToast(error instanceof Error ? error.message : '플랜 생성 중 문제가 발생했어요.')
    } finally {
      setIsPlanning(false)
    }
  }

  const chooseSuggestion = (text: string) => {
    setPrompt(text)
    showToast('여행 취향을 플래너에 담았어요.')
  }

  return (
    <main>
      <header className="topbar">
        <a className="brand" href="#top" aria-label="roamly 홈">
          <span className="brand-mark"><Navigation size={19} strokeWidth={2.4} /></span>
          <span>roamly</span>
        </a>

        <nav className={isMenuOpen ? 'nav-links open' : 'nav-links'} aria-label="주요 메뉴">
          <a href="#planner" onClick={() => setIsMenuOpen(false)}>AI 플래너</a>
          <a href="#inspiration" onClick={() => setIsMenuOpen(false)}>여행 영감</a>
          <a href="#how" onClick={() => setIsMenuOpen(false)}>이용 방법</a>
        </nav>

        <div className="header-actions">
          <button className="text-button" onClick={() => showToast('로그인 화면은 API 연동 단계에서 연결됩니다.')}>로그인</button>
          <button className="header-cta" onClick={() => document.querySelector('#planner')?.scrollIntoView({ behavior: 'smooth' })}>내 여행 만들기 <ArrowRight size={15} /></button>
          <button className="menu-button" onClick={() => setIsMenuOpen((open) => !open)} aria-label="메뉴 열기"><Menu size={20} /></button>
        </div>
      </header>

      <section className="hero" id="top">
        <div className="hero-visual" aria-hidden="true">
          <div className="visual-photo" />
          <div className="visual-wash" />
          <div className="stamp stamp-top">SEPTEMBER<br /><strong>JEJU ISLAND</strong></div>
          <div className="hero-route">
            <span className="route-pin pin-a" />
            <span className="route-dash dash-a" />
            <span className="route-pin pin-b" />
          </div>
          <div className="floating-card weather-card"><Umbrella size={17} /><span><strong>제주 22°</strong><small>여행하기 좋은 날</small></span></div>
          <div className="floating-card saved-card"><span className="avatar-stack"><i /><i /><i /></span><span><strong>1.8만 명이</strong><small>이번 주 저장했어요</small></span></div>
        </div>

        <div className="hero-content content-width">
          <p className="eyebrow light"><Sparkles size={14} /> 여행을 더 나답게</p>
          <h1>복잡한 여행 계획,<br /><em>AI에게 맡기세요.</em></h1>
          <p className="hero-copy">가고 싶은 마음만 알려주세요. 동선부터 예산까지,<br className="desktop-only" /> 당신의 취향에 맞는 여행을 설계합니다.</p>
          <div className="hero-bottom">
            <div className="mini-people"><span className="avatar first">J</span><span className="avatar second">M</span><span className="avatar third">S</span><span>이미 <b>24,780+</b>개의 여행이 시작됐어요</span></div>
            <button className="scroll-cue" onClick={() => document.querySelector('#planner')?.scrollIntoView({ behavior: 'smooth' })}><ArrowDownRight size={18} /></button>
          </div>
        </div>
      </section>

      <section className="planner-section" id="planner">
        <div className="content-width planner-intro">
          <div>
            <p className="eyebrow"><Sparkles size={14} /> AI TRIP DESIGNER</p>
            <h2>어떤 여행을<br />꿈꾸고 있나요?</h2>
          </div>
          <p>몇 가지 조건만 알려주면, AI가 이동 시간을 줄이고<br className="desktop-only" /> 취향은 더 채운 여행을 만들어드려요.</p>
        </div>

        <div className="planner-shell content-width">
          <div className="planner-main">
            <label className="prompt-label" htmlFor="trip-prompt">여행을 자유롭게 설명해 주세요</label>
            <div className="prompt-box">
              <Sparkles size={22} />
              <textarea id="trip-prompt" value={prompt} onChange={(event) => setPrompt(event.target.value)} rows={3} />
              <button aria-label="내용 지우기" onClick={() => setPrompt('')}><X size={17} /></button>
            </div>
            <div className="suggestion-row">
              <span>예를 들면</span>
              <button onClick={() => chooseSuggestion('엄마와 함께 걷기 편한 경주 1박 2일, 역사와 맛집 중심으로 부탁해요')}>부모님과 경주 1박 2일</button>
              <button onClick={() => chooseSuggestion('혼자 떠나는 속초 2박 3일, 바다와 조용한 카페 위주로 추천해줘')}>혼자 떠나는 속초</button>
            </div>

            <div className="planner-fields">
              <button className="field-button"><MapPin size={18} /><span><small>어디로</small><strong>제주, 대한민국</strong></span><ChevronDown size={17} /></button>
              <button className="field-button"><CalendarDays size={18} /><span><small>언제</small><strong>9. 11 — 9. 13</strong></span><ChevronDown size={17} /></button>
              <div className="field-button guest-control"><UsersRound size={18} /><span><small>누구와</small><strong>{travelers}명</strong></span><div className="stepper"><button onClick={() => setTravelers((count) => Math.max(1, count - 1))} aria-label="인원 줄이기"><Minus size={13} /></button><button onClick={() => setTravelers((count) => Math.min(9, count + 1))} aria-label="인원 늘리기"><Plus size={13} /></button></div></div>
            </div>

            <div className="preference-block">
              <div className="preference-heading"><span>어떤 순간을 더 많이 담을까요?</span><small>최대 3개</small></div>
              <div className="interest-grid">
                {interests.map((interest) => {
                  const active = selectedInterests.includes(interest.label)
                  return <button key={interest.label} className={active ? 'interest active' : 'interest'} onClick={() => toggleInterest(interest.label)}><i>{interest.icon}</i>{interest.label}{active && <Check size={14} />}</button>
                })}
              </div>
            </div>
          </div>

          <aside className="planner-aside">
            <div className="aside-label"><span className="live-dot" /> AI가 고려하는 것</div>
            <div className="check-list"><span><Check size={14} /> 최적 이동 동선</span><span><Check size={14} /> 실시간 비용 예상</span><span><Check size={14} /> 취향 기반 장소 추천</span></div>
            <div className="pace-picker">
              <span>여행 속도</span>
              <div>
                {(['RELAXED', 'BALANCED', 'ACTIVE'] as TravelPace[]).map((item) => <button key={item} className={pace === item ? 'pace active' : 'pace'} onClick={() => setPace(item)}>{item === 'RELAXED' ? '여유롭게' : item === 'BALANCED' ? '알맞게' : '알차게'}</button>)}
              </div>
            </div>
            <button className="generate-button" onClick={createPlan} disabled={isPlanning || !prompt.trim()}>{isPlanning ? <><span className="spinner" /> AI가 동선을 계산 중이에요</> : <><Sparkles size={18} /> AI 여행 만들기 <ArrowRight size={18} /></>}</button>
            <p className="aside-note">일정은 언제든 직접 수정할 수 있어요.</p>
          </aside>
        </div>
      </section>

      <section className="inspiration" id="inspiration">
        <div className="content-width section-heading">
          <div><p className="eyebrow">CURATED FOR YOU</p><h2>지금, 떠나고 싶은 곳</h2></div>
          <button className="more-button" onClick={() => showToast('더 많은 추천지는 API 데이터로 연결할 수 있어요.')}>모두 보기 <ArrowRight size={16} /></button>
        </div>
        <div className="destination-grid content-width">
          {destinations.map((destination, index) => <article key={destination.title} className={`destination-card card-${index}`} onClick={() => { chooseSuggestion(`${destination.title}에서 ${destination.description}을 느낄 수 있는 2박 3일 여행을 만들어줘`); document.querySelector('#planner')?.scrollIntoView({ behavior: 'smooth' }) }}>
            <img src={destination.image} alt={`${destination.title} 여행지`} />
            <div className="destination-overlay" />
            <div className="destination-top"><span>{destination.tag}</span><button aria-label={`${destination.title} 저장`} onClick={(event) => { event.stopPropagation(); showToast(`${destination.title}을 저장했어요.`) }}><Star size={17} /></button></div>
            <div className="destination-copy"><small>{destination.city}</small><h3>{destination.title}</h3><p>{destination.description}</p><span className="round-arrow"><ArrowRight size={16} /></span></div>
          </article>)}
        </div>
      </section>

      {hasPlan && <section ref={resultRef} className="result-section" id="plan-result">
        <div className="content-width result-header">
          <div><p className="eyebrow"><Check size={14} /> PLAN READY</p><h2>제주에서의 3일,<br />이렇게 시작해볼까요?</h2></div>
          <div className="result-actions"><button onClick={() => showToast('공유 링크를 복사했어요.')}><Copy size={16} /> 공유</button><button className="dark-action" onClick={() => showToast('내 여행에 저장했어요.')}><Luggage size={16} /> 내 여행에 저장</button></div>
        </div>

        <div className="result-grid content-width">
          <div className="itinerary-panel">
            <div className="plan-summary"><div><span className="summary-place"><MapPin size={15} /> JEJU ISLAND</span><h3>친구와 떠나는,<br />느긋한 제주</h3><p>2026. 09. 11 — 09. 13 &nbsp;·&nbsp; {travelers}명</p></div><span className="trip-cover">⌇<i>◌</i></span></div>
            <div className="day-tabs">{['DAY 1', 'DAY 2', 'DAY 3'].map((day, index) => <button key={day} className={activeDay === index ? 'active' : ''} onClick={() => setActiveDay(index)}><span>{day}</span><small>{['금요일', '토요일', '일요일'][index]}</small></button>)}</div>
            <div className="timeline">
              {schedule[activeDay].map((item, index) => <div className="timeline-row" key={`${item.time}-${item.title}`}>
                <time>{item.time}</time>
                <div className={`timeline-icon ${item.type}`}>{iconForType(item.type)}</div>
                <div className="timeline-line">{index < schedule[activeDay].length - 1 && <span />}</div>
                <div className="timeline-content"><div><h4>{item.title}</h4><button aria-label="더보기"><MoreHorizontal size={18} /></button></div><p>{item.description}</p><small><Clock3 size={12} /> {item.duration}</small></div>
              </div>)}
              <button className="add-place" onClick={() => showToast('장소 추가 기능은 일정 수정 API와 연결할 수 있어요.')}><Plus size={16} /> 이 날에 장소 추가하기</button>
            </div>
          </div>

          <aside className="result-aside">
            <div className="map-card">
              <div className="map-grid" />
              <div className="map-water map-water-a" /><div className="map-water map-water-b" />
              <div className="map-route"><i className="route-stop a">1</i><i className="route-stop b">2</i><i className="route-stop c">3</i><i className="route-stop d">4</i></div>
              <div className="map-caption"><span><Navigation size={15} /> DAY {activeDay + 1} ROUTE</span><b>{activeDay === 0 ? '애월 산책과 노을' : activeDay === 1 ? '동쪽 해안 드라이브' : '여유로운 마지막 하루'}</b></div>
              <button className="map-open" onClick={() => showToast('지도 서비스 연동 화면입니다.')}><Compass size={15} /> 지도에서 보기</button>
            </div>
            <div className="cost-card"><div className="cost-heading"><div><span>예상 여행 경비</span><h3>1인 기준 <b>543,000원</b></h3></div><CircleDollarSign size={23} /></div><div className="cost-bar"><i style={{ width: '39%' }} /><i style={{ width: '24%' }} /><i style={{ width: '20%' }} /><i style={{ width: '17%' }} /></div><div className="cost-list"><span><i className="cost-stay" /> 숙소 <b>212,000</b></span><span><i className="cost-move" /> 이동 <b>132,000</b></span><span><i className="cost-food" /> 식비 <b>110,000</b></span><span><i className="cost-play" /> 활동 <b>89,000</b></span></div><button onClick={() => showToast('상세 비용 내역을 불러오는 화면입니다.')}>상세 경비 보기 <ChevronRight size={16} /></button></div>
            <div className="stay-tip"><Hotel size={20} /><div><b>이 동선에 딱 맞는 숙소</b><span>애월 오션뷰 · 2박 212,000원부터</span></div><ChevronRight size={17} /></div>
          </aside>
        </div>
      </section>}

      <section className="how-section" id="how">
        <div className="content-width how-layout"><div><p className="eyebrow">HOW ROAMLY WORKS</p><h2>계획보다<br />여행에 집중하세요.</h2></div><div className="how-steps"><article><span>01</span><h3>여행을 말해요</h3><p>정해진 형식 없이, 떠나고 싶은 마음부터 적어보세요.</p></article><article><span>02</span><h3>AI가 엮어요</h3><p>취향과 이동 시간, 예산을 함께 고려해 길을 찾아요.</p></article><article><span>03</span><h3>내 여행으로 만들어요</h3><p>마음에 드는 일정만 골라 나만의 여행을 완성해요.</p></article></div></div>
      </section>

      <footer><div className="content-width footer-inner"><a className="brand" href="#top"><span className="brand-mark"><Navigation size={17} /></span><span>roamly</span></a><p>Travel, thoughtfully designed.</p><span>© 2026 ROAMLY</span></div></footer>
      {toast && <div className="toast"><Check size={16} /> {toast}</div>}
    </main>
  )
}

export default App
