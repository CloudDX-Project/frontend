@echo off
title roamly 미리보기
cd /d "%~dp0"

set "ROAMLY_NODE=C:\Users\CloudDX\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe"

if not exist "%ROAMLY_NODE%" (
  echo 필요한 실행 도구를 찾지 못했습니다.
  echo Codex에서 이 프로젝트를 다시 열어주세요.
  pause
  exit /b 1
)

if not exist "node_modules\vite\bin\vite.js" (
  echo 처음 한 번만 준비가 필요합니다. Codex에게 알려주세요.
  pause
  exit /b 1
)

start "roamly 미리보기 서버" /D "%~dp0" "%ROAMLY_NODE%" "%~dp0node_modules\vite\bin\vite.js" --host 127.0.0.1 --port 5173

set /a ROAMLY_WAIT_COUNT=0
:wait_for_preview
timeout /t 1 /nobreak >nul
powershell -NoProfile -Command "try { Invoke-WebRequest -UseBasicParsing 'http://127.0.0.1:5173' -TimeoutSec 1 ^| Out-Null; exit 0 } catch { exit 1 }"
if not errorlevel 1 goto open_preview
set /a ROAMLY_WAIT_COUNT+=1
if %ROAMLY_WAIT_COUNT% LSS 15 goto wait_for_preview

:open_preview
start "" "http://127.0.0.1:5173"
