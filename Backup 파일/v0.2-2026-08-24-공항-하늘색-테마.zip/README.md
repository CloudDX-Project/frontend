# roamly — AI 여행 플래너 프론트엔드

AI가 사용자 조건을 바탕으로 여행 동선·일정·예산을 제안하는 React + TypeScript 화면입니다. 현재는 목업 모드가 기본값이며, Spring Boot API가 준비되면 환경 변수 하나로 실제 호출로 전환할 수 있습니다.

## 실행

```bash
pnpm install
pnpm dev
```

`.env.example`을 복사해 `.env`로 만든 뒤 `VITE_USE_MOCK=false`로 변경하면 실제 API를 호출합니다.

## 백엔드 연동 계약 초안

| 목적 | Method | Endpoint | 프런트 전송 값 |
| --- | --- | --- | --- |
| AI 여행 플랜 생성 | POST | `/api/v1/trips/plans` | `prompt`, `destination`, `startDate`, `endDate`, `travelers`, `interests`, `pace`, `budgetPerPerson` |
| 내 여행 목록 | GET | `/api/v1/trips` | 페이지/필터 |
| 여행 상세 | GET | `/api/v1/trips/{tripId}` | - |
| 일정 항목 수정 | PATCH | `/api/v1/trips/{tripId}/itinerary-items/{itemId}` | 시간, 장소, 메모 |
| 로그인 | POST | `/api/v1/auth/login` | 이메일, 비밀번호 |
| 토큰 재발급 | POST | `/api/v1/auth/refresh` | HttpOnly refresh cookie |

- OpenAPI(Swagger)는 `/swagger-ui/index.html`에서 노출하고, 프런트에는 생성된 타입 또는 API 클라이언트를 연결하는 구성을 권장합니다.
- 현재 `src/services/plannerApi.ts`는 `credentials: 'include'`를 사용합니다. Spring Security의 CORS 설정에서 프런트 개발 주소를 허용하고 `allowCredentials(true)`를 설정하세요.
- 액세스 토큰은 가능하면 HttpOnly Secure 쿠키를 권장합니다. 자바스크립트 저장소에 JWT를 장기 보관하지 않는 편이 안전합니다.
