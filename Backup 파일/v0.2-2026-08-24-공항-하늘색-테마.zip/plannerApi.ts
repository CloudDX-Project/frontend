export type TravelPace = 'RELAXED' | 'BALANCED' | 'ACTIVE'

export interface TripPlanRequest {
  prompt: string
  destination: string
  startDate: string
  endDate: string
  travelers: number
  interests: string[]
  pace: TravelPace
  budgetPerPerson: number
}

export interface TripPlanResponse {
  tripId: number
  status: 'DRAFT' | 'COMPLETED'
  createdAt: string
}

const useMock = import.meta.env.VITE_USE_MOCK !== 'false'

/**
 * Spring Security가 JWT를 HttpOnly 쿠키로 설정하는 방식을 기본으로 둡니다.
 * Authorization 헤더 방식이 필요하면 이 함수의 헤더 생성 위치만 교체하면 됩니다.
 */
export async function createTripPlan(payload: TripPlanRequest): Promise<TripPlanResponse> {
  if (useMock) {
    await new Promise((resolve) => window.setTimeout(resolve, 1100))
    return { tripId: 1024, status: 'COMPLETED', createdAt: new Date().toISOString() }
  }

  const response = await fetch('/api/v1/trips/plans', {
    method: 'POST',
    credentials: 'include',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  })

  if (!response.ok) {
    throw new Error('여행 플랜을 만들지 못했습니다. 잠시 후 다시 시도해주세요.')
  }

  return response.json() as Promise<TripPlanResponse>
}
