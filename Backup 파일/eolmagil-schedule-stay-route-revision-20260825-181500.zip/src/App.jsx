import { useEffect, useMemo, useState } from 'react'
import { requestTripPlan } from './api/tripPlanApi'
import hawaiianResortHero from './assets/hero-preview-hawaiian-resort.png'
import santoriniHero from './assets/hero-preview-mediterranean-white-city.png'
import citySkylineHero from './assets/hero-preview-city-skyline.png'
import jejuCoastPhoto from './assets/jeju-main-hero.jpeg'

const heroSlides = [
  { id: 'uyuni', src: 'https://wallpapercat.com/w/full/1/a/3/695587-2376x1584-desktop-hd-salar-de-uyuni-bolivia-background.jpg', label: '우유니의 광활한 지평선' },
  { id: 'alps', src: 'https://images.unsplash.com/photo-1596716113965-14a07350eb49?auto=format&fit=crop&fm=jpg&ixlib=rb-4.1.0&q=85&w=2400', label: '초록 알프스와 여유로운 길' },
  { id: 'hawaiian-resort', src: hawaiianResortHero, label: '햇살 가득한 하와이 리조트' },
  { id: 'santorini', src: santoriniHero, label: '푸른 바다의 산토리니' },
  { id: 'city-skyline', src: citySkylineHero, label: '도시 스카이라인 드라이브' },
]

const images = {
  jeju: jejuCoastPhoto,
  fukuoka: 'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?auto=format&fit=crop&w=1600&q=90',
  bangkok: 'https://images.unsplash.com/photo-1563492065599-3520f775eeed?auto=format&fit=crop&w=1600&q=90',
  newyork: 'https://images.unsplash.com/photo-1485871981521-5b1fd3805eee?auto=format&fit=crop&w=1600&q=90',
  coast: 'https://cdn.sisunnews.co.kr/news/photo/201810/91116_202218_2718.jpg',
}
const destinations = [{ id: 'jeju', title: '제주도', city: 'Jeju, Korea', tag: '돌하르방과 푸른 바다', image: images.jeju }, { id: 'fukuoka', title: '후쿠오카', city: 'Fukuoka, Japan', tag: '다자이후와 골목의 여유', image: images.fukuoka }, { id: 'bangkok', title: '방콕', city: 'Bangkok, Thailand', tag: '왓 아룬 너머의 노을', image: images.bangkok }, { id: 'newyork', title: '뉴욕', city: 'New York, USA', tag: '맨해튼의 화려한 하루', image: images.newyork }]
const quickLinks = [{ icon: '✦', title: 'AI 일정 설계', text: '조건만 고르면 일정 완성', target: '#planner' }, { icon: '✈', title: '항공권 비교', text: '출발지와 날짜별 비교', target: '#planner' }, { icon: '⌂', title: '숙소 찾기', text: '국내·해외 숙소 한눈에', target: '#planner' }, { icon: '🚗', title: '렌터카·교통', text: '이동 수단부터 편하게', target: '#planner' }, { icon: '☕', title: '맛집·카페', text: '여행지별 취향 추천', target: '#planner' }, { icon: '♨', title: '온천·힐링', text: '온전한 쉼을 위한 여행', target: '#planner' }]
const paceOptions = ['여유롭게', '보통', '빡빡하게']
const themeOptions = [{ title: '맛집', image: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=500&q=88' }, { title: '관광', image: 'https://images.unsplash.com/photo-1467269204594-9661b134dd2b?auto=format&fit=crop&w=500&q=88' }, { title: '휴식', image: 'https://images.unsplash.com/photo-1540541338287-41700207dee6?auto=format&fit=crop&w=500&q=88' }, { title: '자연', image: 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?auto=format&fit=crop&w=500&q=88' }, { title: '액티비티', image: 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=500&q=88' }, { title: '쇼핑', image: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=500&q=88' }]
const outboundOptions = [{ id: 'CAR', icon: '🚙', title: '자차·선박', text: '내 차와 함께 이동' }, { id: 'FLIGHT', icon: '✈', title: '항공', text: '가장 빠른 제주 이동' }, { id: 'KTX', icon: '🚆', title: 'KTX', text: '기차와 선박 연계' }, { id: 'BUS', icon: '🚌', title: '고속버스', text: '버스와 선박 연계' }, { id: 'OTHER', icon: '＋', title: '기타', text: '직접 입력·나중에 결정' }]
const localOptions = [{ id: 'RENTAL', icon: '🚗', title: '렌터카', text: '자유로운 동선 추천' }, { id: 'TRANSIT', icon: '🚌', title: '대중교통', text: '버스 중심으로 이동' }, { id: 'TAXI', icon: '🚕', title: '택시·카셰어링', text: '필요할 때만 편하게' }, { id: 'OTHER', icon: '＋', title: '기타', text: '직접 입력·나중에 결정' }]
const departureTimeOptions = ['06:00', '07:00', '08:00', '09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00']
const returnTimeOptions = ['11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00', '21:00', '22:00']
const transportName = (id, options) => options.find((option) => option.id === id)?.title || '미선택'
const rentals = [
  { id: 'billycar', company: '빌리카', car: '더 뉴 레이 · 경차', price: 89800, originalPrice: 133000, discount: 32, badge: '오늘만 특가', left: 3, note: '2박 3일 48시간 · 완전자차 포함 기준', insurance: '완전자차', fuel: '가득 반납', pickup: '공항 셔틀 8분', cancellation: '전날 17시까지 무료', score: '4.82', reviews: 4821, age: '만 21세 · 1년', benefit: '완전자차 포함 · 전날까지 무료 취소' },
  { id: 'jeju-pass', company: '제주패스 렌터카', car: 'K3 · 준중형', price: 112000, badge: '제휴 특가', left: 5, note: '2박 3일 48시간 · 자차 포함 기준', insurance: '자차 포함', fuel: '가득 반납', pickup: '공항 셔틀 10분', cancellation: '전날 17시까지 무료', score: '4.76', reviews: 3926, age: '만 21세 · 1년', benefit: '준중형 K3 · 자차 포함으로 넉넉한 이동' },
  { id: 'sk-rent', company: 'SK렌터카 제주', car: '캐스퍼 · 경형 SUV', price: 128000, badge: '빠른 인수', left: 4, note: '2박 3일 48시간 · 자차 선택 기준', insurance: '일반자차', fuel: '가득 반납', pickup: '공항 셔틀 7분', cancellation: '24시간 전 무료', score: '4.79', reviews: 3670, age: '만 21세 · 1년', benefit: '공항 셔틀 7분 · 24시간 전까지 무료 취소' },
  { id: 'lotte-rent', company: '롯데렌터카 제주', car: '코나 · SUV', price: 156000, badge: '인기 차종', left: 2, note: '2박 3일 48시간 · 자차 포함 기준', insurance: '완전자차', fuel: '가득 반납', pickup: '오토하우스 셔틀', cancellation: '전날 17시까지 무료', score: '4.88', reviews: 6452, age: '만 21세 · 1년', benefit: 'SUV · 완전자차 포함 · 오토하우스 셔틀' },
  { id: 'd-rent', company: '디렌트카', car: '아반떼 · 준중형', price: 119000, badge: '후기 추천', left: 6, note: '2박 3일 48시간 · 자차 선택 기준', insurance: '일반자차', fuel: '가득 반납', pickup: '공항 셔틀 12분', cancellation: '48시간 전 무료', score: '4.71', reviews: 2814, age: '만 21세 · 1년', benefit: '48시간 전 무료 취소 · 준중형 선택' },
  { id: 'free-rent', company: '자유렌터카', car: '니로 EV · 전기차', price: 144000, badge: '친환경 픽', left: 3, note: '2박 3일 48시간 · 충전카드 포함 기준', insurance: '완전자차', fuel: '충전 70% 반납', pickup: '공항 셔틀 10분', cancellation: '전날 17시까지 무료', score: '4.75', reviews: 3198, age: '만 26세 · 2년', benefit: '충전카드 · 완전자차 포함으로 추가비용 절감' },
]
const rentalImages = {
  billycar: 'https://images.unsplash.com/photo-1494905998402-395d579af36f?auto=format&fit=crop&w=900&q=88',
  'jeju-pass': 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=900&q=88',
  'sk-rent': 'https://images.unsplash.com/photo-1542282088-72c9c27ed0cd?auto=format&fit=crop&w=900&q=88',
  'lotte-rent': 'https://images.unsplash.com/photo-1552519507-da3b142c6e3d?auto=format&fit=crop&w=900&q=88',
  'd-rent': 'https://images.unsplash.com/photo-1504215680853-026ed2a45def?auto=format&fit=crop&w=900&q=88',
  'free-rent': 'https://images.unsplash.com/photo-1494976388531-d1058494cdd8?auto=format&fit=crop&w=900&q=88',
}
const domestic = ['서울', '부산', '제주도', '전주', '경주', '여수', '가평·춘천', '속초']
const overseas = ['후쿠오카', '방콕', '뉴욕', '오사카', '다낭', '타이베이', '파리', '시드니']
const placePhotos = [images.coast, images.fukuoka, images.newyork, 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=900&q=88', images.jeju, 'https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=900&q=88', 'https://images.unsplash.com/photo-1519681393784-d120267933ba?auto=format&fit=crop&w=900&q=88', 'https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=900&q=88']
const carriers = [
  ['대한항공', 'KE 1201 · KE 1248', '07:15 → 08:25', '19:50 → 21:00', 218000, 'navy'], ['아시아나항공', 'OZ 8111 · OZ 8142', '08:25 → 09:35', '20:10 → 21:20', 205000, 'brown'], ['제주항공', '7C 401 · 7C 432', '10:15 → 11:25', '20:40 → 21:50', 142800, 'orange'], ['티웨이항공', 'TW 501 · TW 536', '11:30 → 12:40', '19:05 → 20:15', 148900, 'red'], ['대한항공', 'KE 1211 · KE 1158', '12:50 → 14:00', '18:30 → 19:40', 238000, 'navy'], ['진에어', 'LJ 401 · LJ 430', '13:40 → 14:50', '20:15 → 21:25', 154600, 'green'], ['에어부산', 'BX 401 · BX 432', '14:30 → 15:40', '19:30 → 20:40', 149800, 'blue'], ['대한항공', 'KE 1131 · KE 1168', '16:05 → 17:15', '20:35 → 21:45', 245000, 'navy'], ['이스타항공', 'ZE 401 · ZE 436', '17:20 → 18:30', '21:05 → 22:15', 139900, 'purple'], ['제주항공', '7C 111 · 7C 136', '18:10 → 19:20', '21:25 → 22:35', 135800, 'orange'],
]
const incheonCarriers = [['대한항공', 'KE 1107 · KE 1160', '06:35 → 07:45', '18:45 → 19:55', 264000, 'navy'], ['아시아나항공', 'OZ 8911 · OZ 8924', '07:50 → 09:00', '20:20 → 21:30', 221000, 'brown'], ['진에어', 'LJ 531 · LJ 548', '09:15 → 10:25', '19:35 → 20:45', 168000, 'green'], ['제주항공', '7C 871 · 7C 886', '10:50 → 12:00', '21:05 → 22:15', 151000, 'orange'], ['티웨이항공', 'TW 721 · TW 738', '12:15 → 13:25', '18:10 → 19:20', 159000, 'red'], ['에어부산', 'BX 821 · BX 836', '13:40 → 14:50', '20:40 → 21:50', 163000, 'blue'], ['대한항공', 'KE 1119 · KE 1172', '15:10 → 16:20', '21:20 → 22:30', 278000, 'navy'], ['이스타항공', 'ZE 721 · ZE 736', '16:35 → 17:45', '19:10 → 20:20', 146000, 'purple'], ['제주항공', '7C 883 · 7C 898', '18:05 → 19:15', '20:55 → 22:05', 154000, 'orange'], ['진에어', 'LJ 539 · LJ 556', '19:25 → 20:35', '22:10 → 23:20', 171000, 'green']]
const flightDeals = {
  'GMP-2': { fare: 89900, originalFare: 169000, discount: 47, seats: 3 },
  'GMP-3': { fare: 94900, originalFare: 160900, discount: 41, seats: 4 },
  'ICN-0': { fare: 149000, originalFare: 264000, discount: 44, seats: 2 },
  'ICN-7': { fare: 99900, originalFare: 169900, discount: 41, seats: 3 },
}
const flights = [...carriers.map(([airline, code, out, back, fare, tone], index) => ({ id: `GMP-${index}`, origin: 'GMP', airline, code, out, back, fare: fare - 6000, tone })), ...incheonCarriers.map(([airline, code, out, back, fare, tone], index) => ({ id: `ICN-${index}`, origin: 'ICN', airline, code, out, back, fare, tone }))].map((flight) => ({ ...flight, ...(flightDeals[flight.id] || {}) }))
const saleFlightIds = new Set(Object.keys(flightDeals))
const isSaleFlight = (flight) => saleFlightIds.has(flight.id)
const hotelImages = ['https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=1200&q=90', 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=1200&q=90', 'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=90', 'https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?auto=format&fit=crop&w=1200&q=90', 'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?auto=format&fit=crop&w=1200&q=90', 'https://images.unsplash.com/photo-1445019980597-93fa8acb246c?auto=format&fit=crop&w=1200&q=90', 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?auto=format&fit=crop&w=1200&q=90', 'https://images.unsplash.com/photo-1564501049412-61c2a3083791?auto=format&fit=crop&w=1200&q=90', 'https://images.unsplash.com/photo-1562790351-d273a961e0e9?auto=format&fit=crop&w=1200&q=90', 'https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=1200&q=90', 'https://images.unsplash.com/photo-1584132967334-10e028bd69f7?auto=format&fit=crop&w=1200&q=90', 'https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?auto=format&fit=crop&w=1200&q=90', 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1200&q=90', 'https://images.unsplash.com/photo-1571896349842-33c89424de2d?auto=format&fit=crop&w=1200&q=90', 'https://images.unsplash.com/photo-1601918774946-25832a4be0d6?auto=format&fit=crop&w=1200&q=90', 'https://images.unsplash.com/photo-1618773928121-c32242e63f39?auto=format&fit=crop&w=1200&q=90', 'https://images.unsplash.com/photo-1556740758-90de374c12ad?auto=format&fit=crop&w=1200&q=90', 'https://images.unsplash.com/photo-1511818966892-d7d671e672a2?auto=format&fit=crop&w=1200&q=90', 'https://images.unsplash.com/photo-1578683010236-d716f9a3f461?auto=format&fit=crop&w=1200&q=90', 'https://images.unsplash.com/photo-1540541338287-41700207dee6?auto=format&fit=crop&w=1200&q=90']
const hotelPhotoOverrides = { '메종 글래드 제주': 'https://tong.visitkorea.or.kr/cms/resource/59/2476659_image2_1.jpg', '롯데시티호텔 제주': 'https://d2pyzcqibfhr70.cloudfront.net/images/0/2023-07-19/KEJG1T2NOrFDhHNeFzMmXzvjmlMk5WrYI7oTviX1.jpg', '호텔 난타 제주': 'https://images.trvl-media.com/lodging/18000000/17370000/17363100/17363086/66e16674.jpg?impolicy=resizecrop&ra=fill&rh=575&rw=575', '호텔 리젠트마린 제주': 'https://yaimg.yanolja.com/v5/2022/09/27/11/1280/6332e0447706b9.59126938.jpg', '마레보 비치 호텔': 'https://yaimg.yanolja.com/v5/2024/12/17/03/1280/6760f4fe5d3889.80696667.jpg', '탐라스테이 호텔 제주': 'https://yaimg.yanolja.com/v5/2022/09/01/14/1280/6310c11a953111.27194708.jpg', '한림리조트': 'https://images.trvl-media.com/lodging/6000000/5970000/5963800/5963738/9836e8c1.jpg?impolicy=resizecrop&ra=fill&rh=575&rw=575', '호텔 더 그랑 중문': 'https://cf.bstatic.com/xdata/images/hotel/max1024x768/269097594.jpg?k=a71d4e65e24de3e8b631d897c8fa2a31670721618dcbed438d95c136a50e8aa1&o=', '제주 부영호텔&리조트': 'https://cdn.ostrovok.ru/t/1200x616/content/75/72/7572c5144344c41e4c9d8f59411ca562a2e98c14.jpeg', '히든 클리프 호텔&네이쳐': 'https://cf.bstatic.com/xdata/images/hotel/max1024x768/230411426.jpg?k=efef58e0d78db08d22efa503dfa12d003cd4631404646576c00567d777374fdc&o=' }
const hotelGroups = [['제주공항·시내', [['메종 글래드 제주', 185000], ['롯데시티호텔 제주', 198000], ['신라스테이 제주', 178000], ['호텔 난타 제주', 142000], ['호텔 리젠트마린 제주', 164000]]], ['애월', [['마레보 비치 호텔', 190000], ['다인오세아노 호텔', 176000], ['탐라스테이 호텔 제주', 154000], ['스탠포드 호텔앤리조트 제주', 198000], ['애월 스테이 인 제주', 138000]]], ['협재·한림', [['블루스프링 부띠끄 호텔', 168000], ['한림리조트', 149000], ['라온 호텔 앤 리조트', 156000], ['제주 라온프라이빗타운', 192000], ['한림오션캐슬', 134000]]], ['중문·서귀포', [['호텔 더 그랑 중문', 172000], ['제주 부영호텔&리조트', 198000], ['히든 클리프 호텔&네이쳐', 199000], ['골든데이지 서귀포 오션 호텔', 139000], ['호텔 케니 서귀포', 126000]]]]
hotelGroups.push(['기타 지역', []])
const stays = hotelGroups.flatMap(([area, list], region) => list.map(([name, price], index) => { const order = region * 5 + index; return { id: `${region}-${index}`, area, name, price, image: hotelPhotoOverrides[name] || hotelImages[order % hotelImages.length], rating: (4.97 - order * 0.021).toFixed(2), reviewCount: 3460 + ((order * 317) % 4210), deal: [0, 6, 11, 17].includes(order), left: 2 + order % 5, insight: region === 1 ? '애월 해안 동선과 노을 시간에 잘 맞아요.' : region === 2 ? '협재·한림 해변을 둘러보기 좋은 위치예요.' : region === 3 ? '중문 관광지와 휴식 일정을 함께 즐기기 좋아요.' : '공항 접근성과 첫날 동선이 편리해요.' } }))
const days = [['공항에서 애월의 노을까지', '첫날은 이동 시간을 여유롭게 두고 서쪽 바다를 만나요.', [['10:10', '✈', '제주국제공항 도착', '수하물 수령 후, 미리 선택한 현지 이동 수단으로 여행을 시작해요.', '50분'], ['11:05', '🚗', '렌터카 수령 · 출발 준비', '차량 상태와 보험을 확인하고 애월 방향으로 출발해요.', '35분'], ['11:50', '🍚', '이춘옥 원조고등어쌈밥', '애월의 실제 고등어쌈밥 식당에서 첫 끼를 여유롭게 즐겨요.', '70분'], ['13:25', '◌', '한담해안산책로', '곽지에서 한담까지 이어지는 바닷길을 천천히 걸어요.', '90분'], ['15:20', '☕', '애월 카페 거리', '노을 시간 전, 바다 전망 카페에서 휴식과 사진 시간을 가져요.', '75분'], ['17:20', '⌂', '선택한 숙소 체크인', '선택한 숙소 위치를 기준으로 동선을 마무리하고 잠시 쉬어가요.', '80분'], ['19:10', '🍊', '애월 저녁 · 로컬 메뉴', '숙소와 가까운 지역 맛집에서 제주 첫날의 저녁을 즐겨요.', '90분']]], ['협재의 물빛과 제주 숲', '바다·초록·노을을 한 번에 담는 서쪽 중심의 하루예요.', [['08:30', '🥐', '숙소 조식 · 출발 준비', '조식과 이동 시간을 고려해 여유롭게 하루를 열어요.', '60분'], ['09:50', '⌇', '협재 해수욕장', '비양도가 보이는 얕고 맑은 바다에서 산책과 물빛을 즐겨요.', '100분'], ['11:40', '◌', '금능해변 산책', '협재와 이어지는 조용한 해변에서 사진을 남겨요.', '55분'], ['12:50', '🍜', '한림 로컬 점심', '오후 숲·오름 동선 전, 한림에서 가볍게 점심을 즐겨요.', '70분'], ['14:20', '🌿', '오설록 티 뮤지엄', '녹차밭과 티 라운지에서 제주만의 쉼을 경험해요.', '95분'], ['16:30', '◌', '새별오름', '해 질 무렵 가벼운 오름 산책으로 서쪽 풍경을 바라봐요.', '80분'], ['18:30', '🍽', '제주 흑돼지 저녁', '하루의 마지막은 이동 동선을 줄인 저녁 식사로 마무리해요.', '100분']]], ['제주를 담아 돌아가는 날', '체크아웃부터 공항까지 여유 시간을 확보한 귀가 동선이에요.', [['08:40', '⌂', '체크아웃 · 짐 정리', '출발 전 짐을 싣고 마지막 바다를 보기 위한 준비를 해요.', '35분'], ['09:30', '◌', '곽지해수욕장', '체크아웃 뒤 마지막 바다 산책과 기념 사진을 남겨요.', '55분'], ['10:45', '☕', '제주 로컬 카페', '공항 이동 전, 제주 감성이 남은 카페에서 잠시 쉬어가요.', '50분'], ['11:50', '🍊', '동문시장', '선물과 제주 간식을 한곳에서 고르고 포장 시간을 확보해요.', '85분'], ['13:30', '🍜', '제주시 로컬 점심', '공항 근처에서 가볍게 제주 한 끼를 즐겨요.', '65분'], ['14:50', '🚗', '렌터카 반납 · 공항 이동', '주유와 차량 반납 시간을 여유 있게 포함했어요.', '50분'], ['16:00', '✈', '제주국제공항 출발 준비', '수하물 위탁과 면세 쇼핑을 위한 여유 시간 후 귀가해요.', '출발']]]]
const money = (value) => new Intl.NumberFormat('ko-KR').format(Math.round(Number.isFinite(value) ? value : 0))
const today = (() => { const now = new Date(); return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}` })()
const dateLabel = (date) => date ? date.replaceAll('-', '. ') : '날짜 미선택'
const timeLabel = (time) => time || '시간 미선택'
const timeToMinutes = (time) => {
  const [hour = 0, minute = 0] = String(time || '00:00').split(':').map(Number)
  return hour * 60 + minute
}
const minutesToTime = (minutes) => {
  const normalized = ((Math.round(minutes) % 1440) + 1440) % 1440
  return `${String(Math.floor(normalized / 60)).padStart(2, '0')}:${String(normalized % 60).padStart(2, '0')}`
}
const durationToMinutes = (duration) => Number.parseInt(duration, 10) || 55
const shiftDayTimes = (day, fromTime, toTime) => {
  const base = timeToMinutes(fromTime)
  const target = timeToMinutes(toTime)
  const delta = target - base
  return [day[0], day[1], day[2].map(([time, ...rest]) => [minutesToTime(timeToMinutes(time) + delta), ...rest])]
}
const scheduleEvent = (icon, name, detail, duration, travel = 15) => ({ icon, name, detail, duration, travel })
const makeSequentialPlan = (title, description, firstTime, rows) => {
  let cursor = timeToMinutes(firstTime)
  return [title, description, rows.map((row) => {
    const event = [minutesToTime(cursor), row.icon, row.name, row.detail, row.duration, row.travel]
    cursor += durationToMinutes(row.duration) + row.travel
    return event
  })]
}
const stayProfileFor = (stay) => {
  const isHallim = stay?.area === '협재·한림'
  const isAewol = stay?.area === '애월'
  const stayName = stay?.name || '선택한 숙소'
  if (isHallim) return {
    key: 'hallim', stayName, areaLabel: '한림',
    arrivalPlace: '협재해수욕장', arrivalDetail: '한림 숙소 체크인 전, 비양도가 보이는 해변에서 서쪽 바다를 먼저 만나요.',
    dinner: '한림 로컬 저녁', dinnerDetail: '협재·한림 권역 안에서 이동을 줄인 저녁 식사예요.',
    secondDay: [scheduleEvent('🥐', '숙소 조식 · 출발 준비', '한림 숙소에서 조식 후, 해변과 숲 동선을 시작해요.', '60분', 20), scheduleEvent('◌', '금능해변 산책', '협재 바로 옆의 조용한 해변을 여유롭게 걸어요.', '80분', 15), scheduleEvent('🌿', '한림공원', '야자수 길과 정원을 천천히 둘러봐요.', '95분', 20), scheduleEvent('🍜', '한림 로컬 점심', '오설록 방향으로 이동 전, 한림에서 점심을 즐겨요.', '70분', 40), scheduleEvent('🍵', '오설록 티 뮤지엄', '녹차밭과 티 라운지에서 제주만의 쉼을 경험해요.', '100분', 35), scheduleEvent('◌', '새별오름', '노을 시간에 맞춰 서쪽 풍경을 바라봐요.', '80분', 35), scheduleEvent('🍽', '한림 흑돼지 저녁', '숙소 권역으로 돌아와 이동 없이 하루를 마무리해요.', '95분', 15)],
    departurePlace: '협재해수욕장', departureDetail: '체크아웃 뒤 숙소와 가까운 마지막 바다 산책이에요.',
  }
  if (isAewol) return {
    key: 'aewol', stayName, areaLabel: '애월',
    arrivalPlace: '한담해안산책로', arrivalDetail: '애월 숙소 체크인 전, 곽지에서 한담까지 이어지는 바닷길을 걸어요.',
    dinner: '애월 로컬 저녁', dinnerDetail: '애월 숙소와 가까운 로컬 식당에서 첫날을 마무리해요.',
    secondDay: [scheduleEvent('🥐', '숙소 조식 · 출발 준비', '애월 숙소에서 여유롭게 하루를 시작해요.', '60분', 20), scheduleEvent('◌', '곽지해수욕장', '한담과 이어지는 맑은 바다에서 산책과 사진을 즐겨요.', '85분', 20), scheduleEvent('☕', '애월 카페 거리', '오전 바다 전망 카페에서 잠시 쉬어가요.', '70분', 45), scheduleEvent('🌿', '오설록 티 뮤지엄', '녹차밭과 티 라운지에서 제주만의 쉼을 경험해요.', '100분', 35), scheduleEvent('◌', '새별오름', '해 질 무렵 가벼운 오름 산책을 해요.', '80분', 35), scheduleEvent('🍽', '애월 흑돼지 저녁', '숙소로 돌아가는 길에 저녁을 즐겨요.', '95분', 15)],
    departurePlace: '한담해안산책로', departureDetail: '체크아웃 후, 공항으로 향하기 전 마지막 바다를 만나요.',
  }
  return stayProfileFor({ area: '애월', name: stayName })
}
const makeDayPlans = (startTime, endTime, stay) => {
  const profile = stayProfileFor(stay)
  const arrivalAt = timeToMinutes(startTime) + 80
  const arrivalRows = [scheduleEvent('✈', '제주국제공항 도착', '수하물 수령 후, 선택한 제주 이동 수단으로 여행을 시작해요.', '30분', 25), scheduleEvent('🚗', '렌터카 수령 · 출발 준비', '차량 상태와 보험을 확인한 뒤 숙소 권역으로 출발해요.', '35분', 45)]
  if (arrivalAt <= 11 * 60 + 30) arrivalRows.push(scheduleEvent('🍚', '이춘옥 원조고등어쌈밥', '늦지 않은 도착 시간이라 첫 끼를 먼저 즐긴 뒤 서쪽으로 이동해요.', '70분', 20))
  if (arrivalAt <= 15 * 60 + 30) arrivalRows.push(scheduleEvent('◌', profile.arrivalPlace, profile.arrivalDetail, '85분', 20))
  arrivalRows.push(scheduleEvent('⌂', `${profile.stayName} 체크인`, `${profile.areaLabel} 숙소를 기준으로 짐을 풀고 잠시 쉬어가요.`, '55분', 20), scheduleEvent('🍽', profile.dinner, profile.dinnerDetail, '90분', 15))
  if (arrivalAt <= 13 * 60) arrivalRows.splice(arrivalRows.length - 2, 0, scheduleEvent('☕', profile.key === 'hallim' ? '협재 오션 카페' : '애월 카페 거리', '숙소 체크인 전, 바다를 보며 잠시 쉬어가요.', '60분', 15))

  const departureMinutes = timeToMinutes(endTime)
  const earlyReturn = departureMinutes <= 13 * 60
  const departureRows = earlyReturn
    ? [scheduleEvent('⌂', '체크아웃 · 짐 정리', '귀국 시간이 이른 편이라 짐과 차량을 먼저 정리해요.', '35분', 20), scheduleEvent('🚗', '렌터카 반납 · 공항 이동', '주유와 차량 반납, 셔틀 이동 시간을 포함했어요.', '50분', 10), scheduleEvent('✈', '제주국제공항 출발 준비', '출발 90분 전 수하물 위탁과 탑승 준비를 마쳐요.', '출발', 0)]
    : [scheduleEvent('⌂', '체크아웃 · 짐 정리', '숙소에서 짐을 정리한 뒤 마지막 제주 동선을 시작해요.', '35분', 20), scheduleEvent('◌', profile.departurePlace, profile.departureDetail, '65분', 45), scheduleEvent('🍊', '동문시장', '선물과 제주 간식을 한곳에서 고르고 포장 시간을 확보해요.', '80분', 15), scheduleEvent('🍜', '제주시 로컬 점심', '공항 근처에서 가볍게 제주 한 끼를 즐겨요.', '65분', 35), scheduleEvent('🚗', '렌터카 반납 · 공항 이동', '주유와 차량 반납, 셔틀 이동 시간을 포함했어요.', '50분', 10), scheduleEvent('✈', '제주국제공항 출발 준비', '출발 90분 전 수하물 위탁과 탑승 준비를 마쳐요.', '출발', 0)]
  const departureStart = earlyReturn ? Math.max(7 * 60 + 30, departureMinutes - 210) : Math.max(8 * 60 + 30, departureMinutes - 510)
  return [makeSequentialPlan(`공항에서 ${profile.areaLabel}의 첫날까지`, '출발 시간을 반영해 도착·인수·체크인 순서를 현실적으로 배치했어요.', minutesToTime(arrivalAt), arrivalRows), makeSequentialPlan(`${profile.areaLabel} 중심의 제주 하루`, '선택한 숙소 권역을 중심으로 되돌아가는 이동을 줄였어요.', '08:30', profile.secondDay), makeSequentialPlan('제주를 담아 돌아가는 날', '귀국 시각 90분 전 공항 도착을 기준으로 마지막 동선을 설계했어요.', minutesToTime(departureStart), departureRows)]
}
const placeAlternatives = [
  { icon: '🌅', name: '성산일출봉', detail: '동부권 대표 명소를 중심으로 동선과 체험 예산을 다시 계산해요.', duration: '100분', travel: 65 },
  { icon: '🌺', name: '카멜리아힐', detail: '계절 정원 산책을 넣어 서귀포권 이동 시간까지 반영해요.', duration: '95분', travel: 45 },
  { icon: '🖼', name: '아르떼뮤지엄 제주', detail: '실내 전시 관람 시간과 입장권 예산을 포함해 다시 설계해요.', duration: '100분', travel: 35 },
  { icon: '🌊', name: '함덕해수욕장', detail: '동부 바다 산책으로 바꾸고 공항·숙소 이동 거리를 재계산해요.', duration: '85분', travel: 55 },
  { icon: '🛍', name: '동문시장', detail: '제주시 시장 동선을 넣고 간식·선물 예상비용을 반영해요.', duration: '80분', travel: 25 },
  { icon: '☕', name: '애월 카페 거리', detail: '바다 전망 카페 휴식 시간을 넣어 서부권 동선으로 조정해요.', duration: '70분', travel: 30 },
]
const applyPlanEdits = (plans, edits) => plans.map((day, dayIndex) => {
  let cursor = timeToMinutes(day[2][0]?.[0] || '08:30')
  const rows = day[2].map((event, stopIndex) => {
    const replacement = edits[`${dayIndex}-${stopIndex}`]
    const source = replacement ? [event[0], replacement.icon, replacement.name, replacement.detail, replacement.duration, replacement.travel] : event
    const next = [minutesToTime(cursor), ...source.slice(1)]
    cursor += durationToMinutes(source[4]) + (source[5] ?? 15)
    return next
  })
  return [day[0], day[1], rows]
})
const placeEntryCost = (name) => {
  if (name.includes('아르떼뮤지엄')) return 20000
  if (name.includes('카멜리아힐')) return 10000
  if (name.includes('동문시장')) return 14000
  if (name.includes('오설록')) return 12000
  if (name.includes('카페')) return 10000
  if (name.includes('성산일출봉')) return 8000
  return 0
}
const eventPrice = (name, { selectedFlight, selectedRental, selectedStay, party, rooms }) => {
  if (name.includes('제주국제공항')) return selectedFlight?.fare || 0
  if (name.includes('렌터카')) return selectedRental ? selectedRental.price / party : 0
  if (name.includes('체크인') || name.includes('숙소 조식')) return selectedStay ? selectedStay.price * rooms / party : 0
  if (name.includes('흑돼지') || name.includes('로컬 저녁')) return 55000
  if (name.includes('점심') || name.includes('고등어')) return 26000
  return placeEntryCost(name)
}
const getDates = (start, end) => { if (!start) return []; if (!end) return [start]; const dates = []; const last = new Date(`${end}T00:00:00`); for (const day = new Date(`${start}T00:00:00`); day <= last && dates.length < 3; day.setDate(day.getDate() + 1)) dates.push(`${day.getFullYear()}-${String(day.getMonth() + 1).padStart(2, '0')}-${String(day.getDate()).padStart(2, '0')}`); return dates }
const destinationImageByName = {
  '서울': 'https://cdn-imgix.headout.com/media/images/0fa96c69074830eb6d2a9e547bd3f5cc-26089-seoul-namsan-cable-car-weekdays-round-trip-ticket-04.jpg?auto=compress%2Cformat&crop=faces&fit=min&h=651&w=1042',
  '경주': 'https://cdn.visitkorea.or.kr/img/call?cmd=VIEW&id=58d96adb-2534-4f18-9aaf-51ccaefc688a',
  '전주': 'https://tour.jeonju.go.kr/images/visitjj/contents/streetmap/img_hanok00.jpg',
  '제주도': jejuCoastPhoto,
  '부산': 'https://media.grandvoyage.com/__sized__/voyages/Viaje_a_Corea_del_Sur_de_9_dias__de_Seul_a_Busan_pM5Y5VD_urjfjJv-thumbnail_webp-1920x960.webp',
  '여수': 'https://images.unsplash.com/photo-1530789253388-582c481c54b0?auto=format&fit=crop&w=1400&q=90',
  '가평·춘천': 'https://images.unsplash.com/photo-1519681393784-d120267933ba?auto=format&fit=crop&w=1400&q=90',
  '속초': 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=1400&q=90',
  '후쿠오카': 'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?auto=format&fit=crop&w=1400&q=90',
  '방콕': 'https://images.unsplash.com/photo-1563492065599-3520f775eeed?auto=format&fit=crop&w=1400&q=90',
  '뉴욕': 'https://images.unsplash.com/photo-1485871981521-5b1fd3805eee?auto=format&fit=crop&w=1400&q=90',
  '오사카': 'https://images.unsplash.com/photo-1590559899731-a382839e5549?auto=format&fit=crop&w=1400&q=90',
  '다낭': 'https://images.unsplash.com/photo-1583417319070-4a69db38a482?auto=format&fit=crop&w=1400&q=90',
  '타이베이': 'https://images.unsplash.com/photo-1470004914212-05527e49370b?auto=format&fit=crop&w=1400&q=90',
  '파리': 'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?auto=format&fit=crop&w=1400&q=90',
  '시드니': 'https://images.unsplash.com/photo-1523482580672-f109ba8cb9be?auto=format&fit=crop&w=1400&q=90',
}
function RouteMap({ activeDay, dayPlans }) {
  const selectedDay = dayPlans[activeDay] || dayPlans[0]
  const route = {
    label: selectedDay?.[0] || '제주 여행 동선',
    stops: (selectedDay?.[2] || []).map(([, , name]) => name).filter((name) => !name.includes('체크아웃') && !name.includes('출발 준비')).slice(0, 6),
  }
  const encodedStops = route.stops.map((stop) => encodeURIComponent(`${stop}, 제주특별자치도`))
  const mapUrl = `https://www.google.com/maps?output=embed&f=d&saddr=${encodedStops[0]}&daddr=${encodedStops.slice(1).join('+to:')}`
  const openMapUrl = `https://www.google.com/maps/dir/${route.stops.map((stop) => encodeURIComponent(`${stop}, 제주특별자치도`)).join('/')}`

  return <section className="full-route-map" aria-label={`DAY ${activeDay + 1} 지도`}><header><div><span>DAY {activeDay + 1} · 실제 장소 기반 동선</span><b>{route.label}</b></div><a href={openMapUrl} target="_blank" rel="noreferrer">전체 지도 ↗</a></header><div className="route-map-frame"><iframe src={mapUrl} title={`DAY ${activeDay + 1} 제주 동선 지도`} loading="lazy" /><b>DAY {activeDay + 1} ROUTE</b><div className="route-stop-list">{route.stops.map((stop, index) => <span key={stop}><i>{index + 1}</i>{stop}</span>)}</div></div></section>
}

function CampusTimetable({ dates, dayPlans }) {
  const hours = Array.from({ length: 16 }, (_, index) => index + 8)
  return <div className="campus-timetable" aria-label="3일 통합 시간표"><div className="timetable-top"><span>TIME</span>{dates.map((date, index) => <b key={date}>DAY {index + 1}<small>{date.slice(5).replace('-', '.')}</small></b>)}</div><div className="timetable-content"><div className="timetable-hours">{hours.map((hour) => <span key={hour}>{String(hour).padStart(2, '0')}:00</span>)}</div>{dayPlans.map((day, dayIndex) => <div className="timetable-day" key={day[0]}>{hours.map((hour) => <i key={hour} />)}{day[2].map(([time, icon, name, detail, duration]) => { const top = Math.max(0, timeToMinutes(time) - 8 * 60); const height = Math.max(46, durationToMinutes(duration)); return <article key={`${dayIndex}-${time}-${name}`} style={{ top: `${top}px`, height: `${height}px` }}><span>{icon}</span><b>{name}</b><small>{time} · {duration}</small></article> })}</div>)}</div></div>
}

function PlanFullscreen({ activeDay, costDetails, dates, dayPlans, endTime, eventCost, money, onChangeStop, onOpenStay, placeOptions, planRevision, selectedFlight, selectedRental, selectedStay, setActiveDay, setPlanRevision, setPlanViewOpen, startTime, total, travelers }) {
  const day = dayPlans[activeDay]
  const [costExpanded, setCostExpanded] = useState(false)
  const [scheduleView, setScheduleView] = useState('timeline')
  const [placePicker, setPlacePicker] = useState(null)
  return <section className="plan-fullscreen" role="dialog" aria-modal="true" aria-label="제주 전체 여행 일정">
    <header className="plan-fullscreen-head">
      <a className="brand" href="#top" onClick={(event) => { event.preventDefault(); setPlanViewOpen(false) }} aria-label="일정 닫기"><BrandPolygon /><strong>얼마길</strong></a>
      <div><span>AI TRIP PLAN · REV {planRevision}</span><b>제주 2박 3일 상세 일정</b></div>
      <button type="button" onClick={() => setPlanViewOpen(false)}>← 메인으로 돌아가기</button>
    </header>
    <div className="plan-fullscreen-body">
      <aside className="full-trip-aside">
        <p>JEJU, KOREA</p><h2>바다와 맛집을 담은<br />친구들과의 제주 여행</h2><span>{dateLabel(dates[0])} {timeLabel(startTime)} — {dateLabel(dates[dates.length - 1])} {timeLabel(endTime)}</span>
        <div className="full-booking-list"><b>✈ {selectedFlight ? `${selectedFlight.airline} 왕복` : '항공편 미선택'}</b><b>⌂ {selectedStay ? `${selectedStay.name} · ${dates.length - 1}박` : '숙소 미선택'}</b><b>🚗 {selectedRental ? `${selectedRental.company} · 48시간` : '현지 이동 미선택'}</b></div>
        <div className="full-day-tabs">{dates.map((date, index) => <button type="button" key={date} className={activeDay === index ? 'active' : ''} onClick={() => { setActiveDay(index); setScheduleView('timeline') }}><small>DAY {index + 1}</small><b>{date.slice(5).replace('-', '.')}</b><span>{dayPlans[index][0]}</span></button>)}</div>
      </aside>
      <main className="full-timetable">
        <div className="full-day-title"><span>DAY {activeDay + 1} · {dates[activeDay]?.slice(5).replace('-', '.')}</span><h1>{scheduleView === 'timeline' ? day[0] : '3일 여행 시간표'}</h1><p>{scheduleView === 'timeline' ? day[1] : '세 날짜의 이동·식사·관광·휴식 시간을 한눈에 비교해 보세요.'}</p><div><button type="button" className={scheduleView === 'timeline' ? 'view-tab active' : 'view-tab'} onClick={() => setScheduleView('timeline')}>일정</button><button type="button" className={scheduleView === 'calendar' ? 'view-tab active' : 'view-tab'} onClick={() => setScheduleView('calendar')}>시간표</button><button type="button" onClick={() => { setPlanRevision((revision) => revision + 1); setActiveDay(0); setScheduleView('timeline') }}>✦ 현재 선택으로 일정 다시 설계</button><button type="button" className="subtle" onClick={onOpenStay}>숙소 변경하기</button></div></div>
        {scheduleView === 'timeline' ? <div className="full-timeline">{day[2].map(([time, icon, name, detail, stay], index) => { const price = eventCost(name); return <article className="itinerary-stop" key={`${time}-${name}`}><time>{time}</time><span>{icon}</span><div><small>STOP {String(index + 1).padStart(2, '0')} · {stay}</small><b>{name}<em className="stop-price">{price ? `예상 1인 ${money(price)}원` : '예상 무료'}</em></b><p>{detail}</p><button type="button" className="stop-change" onClick={() => setPlacePicker({ index, name })}>장소 변경</button></div><i>{index === 0 ? '출발' : index === day[2].length - 1 ? '마무리' : '이동 포함'}</i></article> })}</div> : <CampusTimetable dates={dates} dayPlans={dayPlans} />}
      </main>
      <aside className="full-budget">
        <RouteMap activeDay={activeDay} dayPlans={dayPlans} />
        <section className="full-budget-summary"><div className="full-budget-top"><span>선택한 예약 기준 · 1인 예상 경비</span><h2>1인 {money(total)}원</h2><p>총 {travelers}명 여행비 {money(total * (travelers || 1))}원</p></div><button type="button" className="full-cost-toggle" aria-expanded={costExpanded} onClick={() => setCostExpanded((current) => !current)}><span>{costExpanded ? '상세 경비 접기' : '상세 경비 보기'}</span><b>{costExpanded ? '⌃' : '⌄'}</b></button>{costExpanded && <div className="full-cost-groups">{costDetails.map((group) => <section key={group.group}><h3>{group.group}</h3>{group.rows.map(([name, value, note]) => <p key={name}><span><b>{name}</b><small>{note}</small></span><strong>1인 {money(value)}원</strong></p>)}</section>)}</div>}</section>
        <div className="full-budget-note"><b>✦ AI 일정 반영</b><span>숙소·교통편을 바꾸면 객실 수, 이동 시간, 세부 경비와 추천 동선을 다시 계산합니다.</span></div>
      </aside>
    </div>
    {placePicker && <div className="stop-picker-backdrop" role="presentation"><section className="stop-picker-modal" role="dialog" aria-modal="true" aria-label="장소 변경"><button type="button" className="modal-close" onClick={() => setPlacePicker(null)} aria-label="장소 변경 닫기">×</button><p>✦ 얼마길 AI · ROUTE EDIT</p><h3>{placePicker.name} 대신<br />어디로 가볼까요?</h3><span>장소를 고르면 이후 이동 시간, 지도 경로와 1인 예상 경비를 함께 다시 계산해요.</span><div>{placeOptions.map((place) => <button type="button" key={place.name} onClick={() => { onChangeStop(activeDay, placePicker.index, place); setPlacePicker(null) }}><i>{place.icon}</i><b>{place.name}</b><small>{place.duration} · 이동 {place.travel}분</small></button>)}</div></section></div>}
  </section>
}
function BrandPolygon() {
  return <span className="brand-mark brand-suitcase" aria-hidden="true"><svg viewBox="0 0 64 64"><rect className="suitcase-body" x="12" y="29" width="40" height="25" rx="8" /><path className="suitcase-handle" d="M26 29v-5c0-3 2-5 5-5h2c3 0 5 2 5 5v5" /><path className="suitcase-palm" d="M32 29V13m0 5c-7-8-12-5-14-2m14 2c7-8 12-5 14-2" /><path className="suitcase-line" d="M18 39h28" /><circle className="suitcase-wheel" cx="20" cy="57" r="3" /><circle className="suitcase-wheel" cx="44" cy="57" r="3" /></svg></span>
}
function App() {
  const [destinationType, setDestinationType] = useState(''); const [destination, setDestination] = useState(''); const [menuOpen, setMenuOpen] = useState(false); const [customDestination, setCustomDestination] = useState('')
  const [prompt, setPrompt] = useState(''); const [startDate, setStartDate] = useState(today); const [endDate, setEndDate] = useState(''); const [startTime, setStartTime] = useState('09:00'); const [endTime, setEndTime] = useState('18:00'); const [travelers, setTravelers] = useState(null); const [travelerInput, setTravelerInput] = useState(''); const [budget, setBudget] = useState(600000); const [pace, setPace] = useState('보통'); const [themes, setThemes] = useState(['맛집', '관광'])
  const [heroSlideIndex, setHeroSlideIndex] = useState(0)
  const [transportPromptReady, setTransportPromptReady] = useState(false)
  useEffect(() => {
    const slideTimer = window.setInterval(() => setHeroSlideIndex((current) => (current + 1) % heroSlides.length), 7000)
    return () => window.clearInterval(slideTimer)
  }, [])
  useEffect(() => {
    if (destination === '제주도' && endDate && travelers && transportPromptReady) {
      setTransportStep('outbound')
      setTransportModalOpen(true)
      setTransportPromptReady(false)
    }
  }, [destination, endDate, travelers, transportPromptReady])
  const [transport, setTransport] = useState(''); const [localTransport, setLocalTransport] = useState(''); const [transportModalOpen, setTransportModalOpen] = useState(false); const [transportStep, setTransportStep] = useState('outbound'); const [origin, setOrigin] = useState('GMP'); const [flightOpen, setFlightOpen] = useState(false); const [flightId, setFlightId] = useState(''); const [rentalOpen, setRentalOpen] = useState(false); const [rentalId, setRentalId] = useState(''); const [stayOpen, setStayOpen] = useState(false); const [stayArea, setStayArea] = useState('전체'); const [stayCustomArea, setStayCustomArea] = useState(''); const [priceBand, setPriceBand] = useState('10-20'); const [staySearch, setStaySearch] = useState(''); const [staySort, setStaySort] = useState('deal'); const [stayId, setStayId] = useState(''); const [showPlan, setShowPlan] = useState(false); const [planViewOpen, setPlanViewOpen] = useState(false); const [planRevision, setPlanRevision] = useState(1); const [activeDay, setActiveDay] = useState(0); const [planEdits, setPlanEdits] = useState({}); const [message, setMessage] = useState('')
  useEffect(() => {
    const filterBar = document.querySelector('.stay-picker .area-filters')
    if (!filterBar) return undefined
    let field = document.querySelector('.stay-picker .custom-area-field')
    if (!field) {
      field = document.createElement('label')
      field.className = 'custom-area-field'
      const icon = document.createElement('span'); icon.textContent = '⌖'
      const input = document.createElement('input'); input.type = 'text'; input.placeholder = '지역 이름을 입력하세요'; input.setAttribute('aria-label', '기타 숙소 지역 입력')
      const hint = document.createElement('small'); hint.textContent = '입력한 지역은 AI 일정 재설계에 반영돼요.'
      input.addEventListener('input', (event) => setStayCustomArea(event.currentTarget.value))
      field.append(icon, input, hint)
      filterBar.insertAdjacentElement('afterend', field)
    }
    const input = field.querySelector('input')
    if (input && input.value !== stayCustomArea) input.value = stayCustomArea
    return undefined
  }, [stayArea, stayCustomArea, stayOpen])
  const isJeju = destination === '제주도'; const selectedFlight = flights.find((flight) => flight.id === flightId); const selectedRental = rentals.find((rental) => rental.id === rentalId); const selectedStay = stays.find((stay) => stay.id === stayId); const dates = getDates(startDate, endDate); const nights = Math.max(1, dates.length - 1); const rooms = selectedStay ? Math.ceil((travelers || 1) / 3) : 0; const baseDayPlans = useMemo(() => makeDayPlans(startTime, endTime, selectedStay), [endTime, selectedStay, startTime]); const dayPlans = useMemo(() => applyPlanEdits(baseDayPlans, planEdits), [baseDayPlans, planEdits]); const placeEditAdjustment = Object.values(planEdits).reduce((sum, place) => sum + placeEntryCost(place.name) - 32000, 0)
  const flightTimeScore = (flight) => Math.abs(timeToMinutes(flight.out.slice(0, 5)) - timeToMinutes(startTime)) + Math.abs(timeToMinutes(flight.back.slice(0, 5)) - timeToMinutes(endTime))
  const filteredFlights = flights.filter((flight) => flight.origin === origin); const saleFirstFlights = [...filteredFlights].sort((a, b) => Number(isSaleFlight(b)) - Number(isSaleFlight(a)) || flightTimeScore(a) - flightTimeScore(b) || a.fare - b.fare); const filteredStays = stays.filter((stay) => priceBand === '10-20' && (stayArea === '전체' || stayArea === '기타 지역' || stay.area === stayArea) && stay.name.toLowerCase().includes(staySearch.toLowerCase())).sort((a, b) => staySort === 'price' ? a.price - b.price : Number(b.deal) - Number(a.deal) || a.price - b.price)
  const items = useMemo(() => { const party = travelers || 1; return [{ name: '항공', total: selectedFlight ? selectedFlight.fare : 0, color: 'flight' }, { name: '숙소', total: selectedStay ? selectedStay.price * nights * rooms / party : 0, color: 'stay' }, { name: '렌터카·주유', total: selectedRental ? (selectedRental.price + 52000) / party : 0, color: 'drive' }, { name: '식비', total: isJeju ? 125000 : 0, color: 'food' }, { name: '관광·체험', total: isJeju ? Math.max(0, 32000 + placeEditAdjustment) : 0, color: 'play' }] }, [isJeju, nights, placeEditAdjustment, rooms, selectedFlight, selectedRental, selectedStay, travelers])
  const costDetails = useMemo(() => {
    const party = travelers || 1
    return [
      { group: '개인 비용', rows: [['왕복 항공권', selectedFlight ? selectedFlight.fare : 0, selectedFlight ? `${selectedFlight.origin === 'GMP' ? '김포' : '인천'} ↔ 제주 · 왕복 1인` : '항공편 미선택'], ['이춘옥 원조고등어쌈밥', isJeju ? 26000 : 0, '고등어쌈밥 1인 정식 예상'], ['애월 카페 · 음료', isJeju ? 10000 : 0, '바다 전망 카페 음료 1잔 기준'], ['한림 로컬 점심', isJeju ? 20000 : 0, '국수·해산물 식사 1회 기준'], ['제주 흑돼지 저녁', isJeju ? 55000 : 0, '흑돼지 180g + 곁들임 1인 기준'], ['동문시장 간식·선물', isJeju ? 14000 : 0, '간식과 소형 기념품 1인 예상'], ['오설록 티 체험', isJeju ? 12000 : 0, '티 라운지 시음·디저트 1인 기준'], ['새별오름 노을 산책', isJeju ? 20000 : 0, '주차·간식·현지 체험비 포함']] },
      { group: `공통 비용 · ${party}명 N/1`, rows: [['렌터카 48시간', selectedRental ? selectedRental.price / party : 0, selectedRental ? `${selectedRental.company} · ${selectedRental.car} · ${party}명 분할` : '렌터카 미선택'], ['주유·주차', selectedRental ? 52000 / party : 0, `서부권 약 120km · 공항·관광지 주차 포함 · ${party}명 분할`], [selectedStay ? `${selectedStay.name} · ${nights}박` : '선택 숙소', selectedStay ? selectedStay.price * nights * rooms / party : 0, selectedStay ? `1박 ${money(selectedStay.price)}원 · 객실 ${rooms}개 · ${party}명 분할` : '숙소 미선택']] },
      ...(Object.values(planEdits).length ? [{ group: '장소 변경 반영 · 1인', rows: Object.values(planEdits).map((place) => [place.name, placeEntryCost(place.name), `${place.name} 선택 기준 입장·체험 예상 비용`]) }] : []),
    ]
  }, [isJeju, nights, planEdits, rooms, selectedFlight, selectedRental, selectedStay, travelers])
  const total = items.reduce((sum, item) => sum + item.total, 0); const gap = Math.abs(budget - total); const inBudget = budget >= total
  const notify = (text) => { setMessage(text); setTimeout(() => setMessage(''), 2600) }; const chooseDestination = (place) => { setDestination(place); setMenuOpen(false); setTransportPromptReady(place === '제주도' && Boolean(endDate && travelers)) }; const chooseCustomDestination = () => { const place = customDestination.trim(); if (!place) return; chooseDestination(place); setCustomDestination('') }; const commitTravelers = () => { if (!travelerInput.trim()) { setTravelers(null); return } const next = Math.min(20, Math.max(1, Math.floor(Number(travelerInput)) || 1)); setTravelerInput(String(next)); setTravelers(next); setTransportPromptReady(destination === '제주도' && Boolean(endDate)) }; const toggleTheme = (theme) => setThemes((current) => current.includes(theme) ? current.filter((item) => item !== theme) : [...current, theme]); const chooseOutbound = (mode) => { setTransport(mode); setTransportStep('local') }; const chooseLocal = (mode) => { setLocalTransport(mode); setTransportModalOpen(false); if (transport === 'FLIGHT') setFlightOpen(true) }; const chooseFlight = (id) => { setFlightId(id); setFlightOpen(false); if (localTransport === 'RENTAL') setRentalOpen(true) }; const chooseRental = (id) => { setRentalId(id); setRentalOpen(false) }; const chooseStay = (id) => { const stay = stays.find((item) => item.id === id); setStayId(id); setPlanEdits({}); setStayOpen(false); if (showPlan && stay) { setPlanRevision((current) => current + 1); notify(`${stay.name} 기준으로 숙소 권역과 세부 경비를 다시 설계했어요.`) } }; const changePlanStop = (dayIndex, stopIndex, place) => { setPlanEdits((current) => ({ ...current, [`${dayIndex}-${stopIndex}`]: place })); setPlanRevision((current) => current + 1); notify(`${place.name} 기준으로 이동 동선과 1인 예상 경비를 다시 계산했어요.`) }; const itineraryEventCost = (name) => eventPrice(name, { selectedFlight, selectedRental, selectedStay, party: travelers || 1, rooms })
  const generate = async () => { if (!isJeju) return notify('국내 여행지에서 제주도를 먼저 선택해 주세요.'); if (!endDate) return notify('귀국일을 먼저 선택해 주세요.'); if (!startTime || !endTime) return notify('출발·귀국 시간을 설정해 주세요.'); if (!travelers) return notify('총인원을 선택해 주세요.'); if (!transport || !localTransport) return notify('AI 교통편 질문에서 출발과 현지 이동을 골라주세요.'); if (transport === 'FLIGHT' && !selectedFlight) return notify('항공편을 선택해 주세요.'); if (!selectedStay) return notify('숙소를 선택해 주세요.'); if (import.meta.env.VITE_USE_MOCK === 'false') await requestTripPlan({ destination, startDate, endDate, startTime, endTime, travelers, total, pace, themes, transport, localTransport }); setActiveDay(0); setPlanRevision((current) => current + 1); setShowPlan(true); setPlanViewOpen(true) }
  return <main>
    <header className="topbar"><a className="brand" href="#top" aria-label="얼마길 처음으로"><BrandPolygon /><strong>얼마길</strong></a><nav><a href="#planner">여행 만들기</a><a href="#inspiration">가이드 추천</a><a href="#how">이용 방법</a></nav><button className="outline-button">로그인</button><button className="header-button" onClick={() => document.querySelector('#planner')?.scrollIntoView({ behavior: 'smooth' })}>여행 만들기 <span>→</span></button></header>
    <section className="hero" id="top">{heroSlides.map((slide, index) => <div key={slide.id} className={`hero-image ${index === heroSlideIndex ? 'is-active' : ''}`} style={{ backgroundImage: `url(${slide.src})` }} aria-hidden={index !== heroSlideIndex} />)}<div className="hero-shade" /><div className="hero-inner"><p className="eyebrow light">YOUR BUDGET, YOUR ROUTE</p><h1>내 예산에 딱 맞춘<br /><i>단 하나의 길, 얼마길.</i></h1><p className="hero-copy">가고 싶은 곳과 사용할 수 있는 예산만 알려주세요.<br />AI가 현실적인 동선과 머무를 이유를 함께 설계합니다.</p><div className="hero-tags"><span>예산 우선 설계</span><span>취향 기반 추천</span><span>낭비 없는 동선</span></div></div><div className="hero-pagination" aria-label="메인 배경 이미지 선택">{heroSlides.map((slide, index) => <button key={slide.id} type="button" className={index === heroSlideIndex ? 'active' : ''} onClick={() => setHeroSlideIndex(index)} aria-label={`${slide.label} 보기`} />)}</div></section><section className="quick-access" aria-label="여행 바로가기"><div className="quick-access-inner">{quickLinks.map((link) => <button type="button" key={link.title} onClick={() => document.querySelector(link.target)?.scrollIntoView({ behavior: 'smooth' })}><span>{link.icon}</span><b>{link.title}</b><small>{link.text}</small></button>)}</div></section>
    <section className="planner-section" id="planner"><div className="section-title"><div><p className="eyebrow">TRIP PLANNING, MADE PERSONAL</p><h2>내 예산 안에서<br />어디로 떠날까요?</h2></div><p>여행의 조건을 알려주면 AI가 비용을 먼저 계산하고,<br />그 안에서 가장 좋은 하루를 찾아드려요.</p></div><div className="planner-card"><div className="form-area">
      <div className="prompt-area"><label htmlFor="prompt">여행을 자유롭게 설명해 주세요</label><div className="prompt-box"><span>●</span><textarea id="prompt" value={prompt} onChange={(e) => setPrompt(e.target.value)} rows="3" placeholder="예: 2박 3일 도쿄 여행, 50만원 예산으로 맛집과 야경을 즐기고 싶어요." /><button type="button" onClick={() => setPrompt('')}>×</button></div></div>
      <section className="budget-input-card early-budget"><div className="budget-input-heading"><div><span>₩</span><b>1인 여행 예산</b><small>모든 개인 비용과 공통 비용의 N/1 금액을 기준으로 비교해요.</small></div><em className={inBudget ? 'safe' : 'over'}>{inBudget ? `예산 안 · ${money(gap)}원 여유` : `예산 초과 · ${money(gap)}원 부족`}</em></div><div className="budget-number"><span>₩</span><input type="text" inputMode="numeric" value={money(budget)} onChange={(e) => setBudget(Number(e.target.value.replaceAll(/[^0-9]/g, '')) || 0)} /><b>원</b><div><small>1인 현재 예상</small><strong>{money(total)}원</strong></div></div><div className="budget-meter"><i className={inBudget ? 'safe' : 'over'} style={{ width: `${Math.min(total / Math.max(budget, 1) * 100, 100)}%` }} /></div></section>
      <div className="form-fields">
        <div className="destination-field"><small>어디로</small><button type="button" className={destination ? 'destination-trigger chosen' : 'destination-trigger'} onClick={() => setMenuOpen(!menuOpen)}><span>●</span><b>{destination || '여행지를 선택해 주세요'}</b><i>⌄</i></button>{menuOpen && <div className="destination-menu"><div className="destination-types"><button type="button" className={destinationType === '국내' ? 'active' : ''} onClick={() => setDestinationType('국내')}>국내</button><button type="button" className={destinationType === '해외' ? 'active' : ''} onClick={() => setDestinationType('해외')}>해외</button></div>{destinationType ? <><div className="destination-cities">{(destinationType === '국내' ? domestic : overseas).map((place, index) => <button type="button" key={place} onClick={() => chooseDestination(place)}><img src={destinationImageByName[place] || placePhotos[index % placePhotos.length]} alt="" /><b>{place}</b></button>)}</div><div className="destination-custom"><input value={customDestination} onChange={(event) => setCustomDestination(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter') { event.preventDefault(); chooseCustomDestination() } }} placeholder={destinationType === '국내' ? '원하는 국내 여행지를 입력하세요' : '원하는 해외 여행지를 입력하세요'} /><button type="button" onClick={chooseCustomDestination}>직접 선택</button></div></> : <p>국내 또는 해외를 먼저 선택해 주세요.</p>}</div>}</div>
        <label className="date-field"><small>언제 · 출발/귀국 날짜와 시간을 한 번에 설정</small><span>▣</span><div className="date-time-range"><div><b>출발</b><label><span>날짜</span><input type="date" value={startDate} onChange={(e) => { setStartDate(e.target.value); if (endDate && endDate < e.target.value) setEndDate(''); setFlightId('') }} /></label><label><span>시간</span><select value={startTime} onChange={(e) => { setStartTime(e.target.value); setFlightId('') }} aria-label="출발 희망 시간">{departureTimeOptions.map((time) => <option value={time} key={time}>{time} 이후</option>)}</select></label></div><i>→</i><div><b>귀국</b><label><span>날짜</span><input type="date" value={endDate} min={startDate} onChange={(e) => { setEndDate(e.target.value); setFlightId(''); setTransportPromptReady(destination === '제주도' && Boolean(travelers)) }} /></label><label><span>시간</span><select value={endTime} onChange={(e) => { setEndTime(e.target.value); setFlightId('') }} aria-label="귀국 희망 시간">{returnTimeOptions.map((time) => <option value={time} key={time}>{time} 이전</option>)}</select></label></div></div></label>
        <div className="traveler-field"><small>총인원</small><label className="traveler-input"><input type="number" min="1" max="20" inputMode="numeric" value={travelerInput} onChange={(event) => setTravelerInput(event.target.value)} onBlur={commitTravelers} onKeyDown={(event) => { if (event.key === 'Enter') { event.preventDefault(); event.currentTarget.blur() } }} placeholder="인원 입력" aria-label="총인원 입력" /><span>명</span></label><small className="traveler-help">입력 완료 후 AI 추천</small></div>
      </div>
      {!isJeju && <div className="waiting-booking"><b>지역을 선택하면 항공편과 숙소를 비교할 수 있어요.</b></div>}
      <section className="preference-area"><div className="pace-preference"><div><small>여행일정</small><b>하루를 어떤 속도로 보낼까요?</b></div><span>{paceOptions.map((option) => <button type="button" key={option} className={pace === option ? 'active' : ''} onClick={() => setPace(option)}>{option}</button>)}</span></div><div className="theme-preference"><div><small>여행 테마</small><b>마음에 드는 테마를 골라주세요.</b></div><span className="theme-cards">{themeOptions.map((theme) => <button type="button" key={theme.title} className={themes.includes(theme.title) ? 'active' : ''} onClick={() => toggleTheme(theme.title)}><img src={theme.image} alt="" /><b>{theme.title}</b></button>)}</span></div></section>
      {isJeju ? <><section className="transport-choice"><div><p>1. AI 교통편 설계</p><small>출발 이동과 제주 현지 이동을 나누어, 실제 여행처럼 함께 설계해요.</small></div><div className="transport-result"><span>출발 <b>{transportName(transport, outboundOptions)}</b></span><i>→</i><span>제주 <b>{transportName(localTransport, localOptions)}</b></span><button type="button" onClick={() => { setTransportStep('outbound'); setTransportModalOpen(true) }}>AI에게 다시 물어보기</button></div></section>{transport === 'FLIGHT' && <section className="booking-section"><div className="booking-heading"><div><p>2. 항공편 선택</p><small>{dateLabel(startDate)} {timeLabel(startTime)} 출발 · {dateLabel(endDate)} {timeLabel(endTime)} 귀국</small></div><em>{selectedFlight ? `${selectedFlight.origin} → CJU 선택됨` : '항공편 미선택'}</em></div><div className="booking-summary"><div><span>✈</span><div><small>{selectedFlight ? `${selectedFlight.origin === 'GMP' ? '김포' : '인천'} → 제주 · 왕복` : '김포 또는 인천 출발'}</small><b>{selectedFlight ? `${selectedFlight.airline} · ${selectedFlight.out}` : 'AI가 항공편을 비교해 드릴게요'}</b></div></div>{selectedFlight && <strong>{money(selectedFlight.fare)}원<small>1인 왕복</small></strong>}<button type="button" onClick={() => setFlightOpen(true)}>{selectedFlight ? '항공편 변경' : '항공편 고르기'} →</button></div></section>}{localTransport === 'RENTAL' && <section className="rental-section"><div className="booking-heading"><div><p>{transport === 'FLIGHT' ? '3.' : '2.'} 제주 렌터카 선택</p><small>{selectedFlight ? `${selectedFlight.airline} 항공 선택 뒤, AI가 2박 3일 동선에 맞춰 비교했어요.` : 'AI가 2박 3일 동선과 여행 인원을 기준으로 비교했어요.'}</small></div><em>2박 3일 · 48시간 비교</em></div><div className="rental-ai-tip"><span>✦</span><p><b>AI 추천</b> 애월·협재·중문까지 이동하는 일정이라면 렌터카가 가장 유연해요. <strong>빌리카</strong>는 현재 비교 목록 중 가장 낮은 가격입니다.</p></div><div className="booking-summary rental-summary"><div><span>🚗</span><div><small>{selectedRental ? `${selectedRental.car} · 2박 3일 48시간 총 대여료` : '제주 현지 이동 수단'}</small><b>{selectedRental ? `${selectedRental.company} · 총 ${money(selectedRental.price)}원` : '2박 3일 특가 렌터카를 팝업에서 비교해 보세요'}</b></div></div>{selectedRental && <strong>총 {money(selectedRental.price)}원<small>2박 3일 · 48시간</small></strong>}<button type="button" onClick={() => setRentalOpen(true)}>{selectedRental ? '렌터카 변경' : '렌터카 고르기'} →</button></div></section>}</> : <div className="waiting-booking"><b>지역을 선택하면 항공편과 숙소를 비교할 수 있어요.</b></div>}
      {isJeju && <section className="booking-section"><div className="booking-heading"><div><p>{transport === 'FLIGHT' && localTransport === 'RENTAL' ? '4.' : '3.'} 숙소 선택</p><small>가격대와 제주 권역을 고른 뒤 숙소를 선택하세요.</small></div><em>{selectedStay ? `${selectedStay.area} · ${nights}박` : '숙소 미선택'}</em></div><div className="booking-summary"><div><span>⌂</span><div><small>{selectedStay ? `${selectedStay.area} · 객실 ${rooms}개` : '제주 전역 숙소'}</small><b>{selectedStay ? selectedStay.name : '가격대와 지역으로 숙소를 찾아보세요'}</b></div></div>{selectedStay && <strong>1박 {money(selectedStay.price)}원</strong>}<button type="button" onClick={() => setStayOpen(true)}>숙소 전체 비교 →</button></div>{stayOpen && <div className="booking-picker stay-picker" role="dialog" aria-modal="true" aria-label="숙소 전체 비교"><header className="stay-modal-head"><div><p>✦ 얼마길 AI · STAY MATCH</p><h3>여행 동선에 맞는 숙소를<br />넓은 화면에서 비교해 보세요.</h3><span>특가세일 객실을 먼저 보여드리고, 가격·권역·후기 점수를 한 번에 비교해요.</span></div><button type="button" className="modal-close" onClick={() => setStayOpen(false)} aria-label="숙소 비교 닫기">×</button></header><div className="stay-ai-recommendation"><span>✦</span><p><b>AI 숙소 추천</b> {selectedStay ? `${selectedStay.name}은 ${selectedStay.insight}` : '특가세일 객실을 먼저 보여드리고, 선택한 동선과 인원에 맞는 숙소를 추천할게요.'}</p><em>특가세일 객실은 빠르게 마감돼요.</em></div><label className="stay-search"><span>⌕</span><input value={staySearch} onChange={(event) => setStaySearch(event.target.value)} placeholder="원하는 숙소 이름을 입력하세요" /></label><div className="stay-toolbar"><div className="price-filters">{[['0-5', '0 ~ 5만원대'], ['5-10', '5 ~ 10만원대'], ['10-20', '10 ~ 20만원대'], ['20-30', '20 ~ 30만원대'], ['30+', '30만원 이상']].map(([id, label]) => <button type="button" className={priceBand === id ? 'active' : ''} onClick={() => setPriceBand(id)} key={id}>{label}</button>)}</div><label className="stay-sort"><span>정렬</span><select value={staySort} onChange={(event) => setStaySort(event.target.value)} aria-label="숙소 정렬 기준"><option value="deal">특가순</option><option value="price">가격순</option></select></label></div><div className="area-filters">{['전체', ...hotelGroups.map(([area]) => area)].map((area) => <button type="button" className={stayArea === area ? 'active' : ''} onClick={() => setStayArea(area)} key={area}>{area}</button>)}</div>{filteredStays.length ? <div className="hotel-catalog">{filteredStays.map((stay) => <button type="button" key={stay.id} className={`${stay.id === stayId ? 'selected' : ''} ${stay.deal ? 'deal-item' : ''}`} onClick={() => chooseStay(stay.id)}><img src={stay.image} alt={`${stay.name} 숙소`} />{stay.deal && <em className="stay-deal">특가세일</em>}<div><span>{stay.area}</span><b>{stay.name}</b><small className="hotel-rating">★ {stay.rating} · 3인 여행 기준 객실</small><strong>1박 {money(stay.price)}원</strong>{stay.deal && <i>잔여 객실 {stay.left}개</i>}</div></button>)}</div> : <div className="empty-catalog"><b>이 가격대의 시연 숙소는 준비 중이에요.</b><span>발표 시나리오용으로 실제 숙소가 포함된 10 ~ 20만원대를 선택해 주세요.</span></div>}</div>}</section>}
    </div><aside className="ai-area"><p><span /> AI TRIP CHECK</p><h3>선택한 예약부터<br />하루의 동선까지.</h3><ul><li>✓ {selectedFlight ? `${selectedFlight.airline} 왕복 ${money(selectedFlight.fare)}원` : '왕복 항공권을 선택해요'}</li><li>✓ {selectedStay ? `${selectedStay.name} ${nights}박` : '제주 숙소를 선택해요'}</li><li>✓ {pace} · {themes.length ? themes.join(' · ') : '테마 선택 전'}</li><li>✓ 선택 즉시 1인 예산 다시 계산</li></ul><div className="selection-total"><small>현재 예상 1인 경비</small><b>{money(total)}원</b><span>총 {travelers || 0}명 여행비 {money(total * (travelers || 0))}원</span></div><button className="generate" type="button" onClick={generate}>내 예산으로 여행 만들기 →</button>{showPlan && <button className="plan-return-button" type="button" onClick={() => setPlanViewOpen(true)}>생성된 전체 일정 보기 →</button>}<small>항공·숙소를 바꾸면 1인 경비와 동선도 바로 반영돼요.</small></aside></div></section>
    <section className="inspiration compact-inspiration" id="inspiration"><div className="section-heading"><div><p className="eyebrow">GUIDE CURATED PLANS</p><h2>가이드 추천 일정</h2></div><button type="button">가이드 전체 보기 →</button></div><div className="city-grid">{destinations.map((place) => <article key={place.id} onClick={() => { setDestinationType(place.id === 'jeju' ? '국내' : '해외'); chooseDestination(place.title); document.querySelector('#planner')?.scrollIntoView({ behavior: 'smooth' }) }}><img src={place.image} alt={`${place.title} 대표 관광지`} /><div><small>GUIDE PICK · {place.city}</small><h3>{place.title}</h3><p>{place.tag}</p><b>가이드 일정 보기 <i>→</i></b></div></article>)}</div></section>
    {planViewOpen && <PlanFullscreen activeDay={activeDay} costDetails={costDetails} dates={dates} dayPlans={dayPlans} endTime={endTime} eventCost={itineraryEventCost} money={money} onChangeStop={changePlanStop} onOpenStay={() => setStayOpen(true)} placeOptions={placeAlternatives} planRevision={planRevision} selectedFlight={selectedFlight} selectedRental={selectedRental} selectedStay={selectedStay} setActiveDay={setActiveDay} setPlanRevision={setPlanRevision} setPlanViewOpen={setPlanViewOpen} startTime={startTime} total={total} travelers={travelers} />}
    {transportModalOpen && <div className="ai-modal-backdrop" role="presentation"><section className="ai-modal" role="dialog" aria-modal="true" aria-labelledby="ai-transport-title"><button type="button" className="modal-close" onClick={() => setTransportModalOpen(false)} aria-label="질문 닫기">×</button><p>✦ 얼마길 AI · {transportStep === 'outbound' ? 'QUESTION 01' : 'QUESTION 02'}</p>{transportStep === 'outbound' ? <><h3 id="ai-transport-title">서울에서 {destination}까지<br />어떻게 이동할까요?</h3><span>선택한 날짜와 총 {travelers}명을 바탕으로 가장 알맞은 이동을 이어서 추천할게요.</span><div className="ai-option-grid">{outboundOptions.map((option) => <button type="button" key={option.id} onClick={() => chooseOutbound(option.id)}><i>{option.icon}</i><b>{option.title}</b><small>{option.text}</small></button>)}</div></> : <><h3 id="ai-transport-title">{destination}에서는<br />어떻게 이동할까요?</h3><span>{transportName(transport, outboundOptions)}을 선택했어요. 현지에서 편한 이동 수단을 골라주세요.</span><div className="ai-option-grid local-options">{localOptions.map((option) => <button type="button" key={option.id} onClick={() => chooseLocal(option.id)}><i>{option.icon}</i><b>{option.title}</b><small>{option.text}</small></button>)}</div><button type="button" className="modal-back" onClick={() => setTransportStep('outbound')}>← 출발 이동 다시 고르기</button></>}</section></div>}
    {flightOpen && <div className="ai-modal-backdrop" role="presentation"><section className="ai-modal flight-modal" role="dialog" aria-modal="true" aria-labelledby="flight-modal-title">
      <button type="button" className="modal-close" onClick={() => setFlightOpen(false)} aria-label="항공편 닫기">×</button>
      <p>✦ 얼마길 AI · FLIGHT MATCH</p>
      <div className="journey-chip"><span>서울</span><i>→</i><b>제주</b><em>항공 선택 단계</em></div>
      <h3 id="flight-modal-title">{dateLabel(startDate)} {timeLabel(startTime)} 이후 출발,<br />가장 알맞은 항공편을 골라주세요.</h3>
      <span>서울 → 제주 이동에서 <b>항공</b>을 선택했어요. 출발 희망 시간 {timeLabel(startTime)}, 귀국 희망 시간 {timeLabel(endTime)}을 기준으로 왕복편을 비교해요.</span>
      <div className="sale-hero"><div><small>TODAY ONLY · 23:59 종료</small><b>오늘만, 정가 대비 최대 47% 할인</b><span>김포·인천 출발별 오늘만 특가 2편을 먼저 보여드려요. 남은 좌석이 적은 순으로 확인하세요.</span></div><strong>✈<small>오늘만<br />특가</small></strong></div>
      <div className="picker-tabs"><button type="button" className={origin === 'GMP' ? 'active' : ''} onClick={() => setOrigin('GMP')}>김포 → 제주</button><button type="button" className={origin === 'ICN' ? 'active' : ''} onClick={() => setOrigin('ICN')}>인천 → 제주</button></div>
      <p className="flight-route-note"><b>{origin === 'GMP' ? '김포 출발' : '인천 출발'}</b> · {origin === 'GMP' ? '이른 출발·늦은 복귀 중심의 국내선 시간표' : '오전·저녁 시간대를 넓게 비교하는 인천 출발 시간표'}</p>
      <p className="picker-date">가는 편 {dateLabel(startDate)} {timeLabel(startTime)} 이후 · 오는 편 {dateLabel(endDate)} {timeLabel(endTime)} 이전 · 오늘만 혜택 {saleFirstFlights.filter(isSaleFlight).length}편</p>
      <div className="flight-catalog">{saleFirstFlights.map((flight) => <button type="button" key={flight.id} className={`${flight.id === flightId ? 'selected' : ''} ${isSaleFlight(flight) ? 'sale-flight' : ''}`} onClick={() => chooseFlight(flight.id)}>{isSaleFlight(flight) && <em className="flight-sale-sticker">오늘만 {flight.discount}% OFF</em>}<span className={`airline-mark ${flight.tone}`}>{flight.airline.slice(0, 1)}</span><div><b>{flight.airline}<small>{flight.code}</small></b><span className="flight-time"><i>가는 편</i>{flight.out}<i>오는 편</i>{flight.back}</span>{isSaleFlight(flight) && <em className="flight-deal">정가 {money(flight.originalFare)}원 → <b>{flight.discount}% 할인</b> · 잔여 {flight.seats}석</em>}</div><strong className={isSaleFlight(flight) ? 'flight-price sale-price' : 'flight-price'}>{isSaleFlight(flight) ? <><del>정가 {money(flight.originalFare)}원</del><b>{money(flight.fare)}원</b><small>{flight.discount}% 할인 · 왕복 1인</small></> : <>{money(flight.fare)}원<small>왕복 1인</small></>}</strong></button>)}</div>
      <button type="button" className="modal-back modal-back-strong" onClick={() => { setFlightOpen(false); setTransportStep('outbound'); setTransportModalOpen(true) }}>← 교통편 선택으로 돌아가기</button>
    </section></div>}
    {rentalOpen && <div className="ai-modal-backdrop" role="presentation"><section className="ai-modal rental-modal" role="dialog" aria-modal="true" aria-labelledby="rental-modal-title">
      <button type="button" className="modal-close" onClick={() => setRentalOpen(false)} aria-label="렌터카 닫기">×</button>
      <p>✦ 얼마길 AI · JEJU DRIVE</p>
      <div className="journey-chip"><span>서울</span><i>→</i><b>제주</b><em>항공 선택 완료</em><i>→</i><b>렌터카</b></div>
      <h3 id="rental-modal-title">제주 2박 3일,<br />총 대여료로 비교해 보세요.</h3>
      <span>{selectedFlight ? `${selectedFlight.airline} 항공편을 고른 뒤` : '항공 이동을 고른 뒤'} 이어서, 출발 {timeLabel(startTime)} · 귀국 {timeLabel(endTime)} 기준 2박 3일 렌터카를 비교했어요.</span>
      <div className="rental-sale-banner"><b>2박 3일 최저가 · 총 대여료 {money(rentals[0].price)}원</b><span>첫날 애월·협재, 마지막 제주시 이동을 고려하면 <strong>공항 인수 방식·자차 보장·무료 취소</strong>를 함께 확인하는 편이 좋아요.</span></div>
      <div className="rental-compare-guide"><b>예약 전 확인할 항목</b><span>총 대여료 · 보험 범위 · 연료/충전 반납 · 공항 셔틀 · 운전자 조건 · 무료 취소</span></div>
      <div className="rental-catalog rental-modal-catalog">{rentals.map((rental) => {
        const isDeal = Boolean(rental.discount)
        return <button type="button" key={rental.id} className={`${rental.id === rentalId ? 'selected' : ''} ${isDeal ? 'rental-deal-card' : ''} ${rental.price >= 128000 ? 'rental-premium' : ''}`} onClick={() => chooseRental(rental.id)}>
          <div className="rental-visual"><img src={rentalImages[rental.id]} alt={`${rental.car} 대표 차량`} /><span>{isDeal ? `${rental.discount}% 특가세일` : rental.badge}</span><i>★ {rental.score} · 잔여 {rental.left}대</i></div>
          <div className="rental-card-body"><b>{rental.company}</b><small>{rental.car} · {rental.age}</small><strong className={isDeal ? 'rental-sale-price' : ''}>{isDeal && <del>정가 {money(rental.originalPrice)}원</del>}<b>{money(rental.price)}원</b>{isDeal && <small>오늘만 {rental.discount}% 할인</small>}</strong><div className="rental-meta"><small><b>보험</b>{rental.insurance}</small><small><b>인수</b>{rental.pickup}</small><small><b>반납</b>{rental.fuel}</small><small><b>취소</b>{rental.cancellation}</small></div><em className="rental-benefit">{rental.benefit}</em><small className="rental-note">{rental.note}</small></div>
        </button>
      })}</div>
      <small className="rental-disclaimer">표시 금액은 2박 3일 48시간 시연 기준이며, 실제 보험·연령·대여 조건은 예약 단계에서 다시 확인해야 합니다.</small>
      <button type="button" className="modal-back modal-back-strong" onClick={() => { setRentalOpen(false); setFlightOpen(true) }}>← 항공편 다시 보기</button>
    </section></div>}
    <section className="how" id="how"><div><p className="eyebrow light">HOW EOLMAGIL WORKS</p><h2>계획은 가볍게,<br />여행은 충분하게.</h2></div><div className="steps"><article><span>01</span><h3>여행지를 고르세요</h3><p>국내와 해외에서 가고 싶은 여행지를 먼저 선택해요.</p></article><article><span>02</span><h3>예약을 비교하세요</h3><p>원하는 교통편과 숙소를 취향에 맞게 고릅니다.</p></article><article><span>03</span><h3>예산과 동선을 확인해요</h3><p>선택한 금액과 여행 루트를 한눈에 확인하세요.</p></article></div></section><footer><b>● 얼마길</b><span>Travel, thoughtfully planned.</span><span className="footer-legal">© 2026 EOLMAGIL <i>·</i> SMART ROUTES, BETTER TRIPS</span></footer>{message && <div className="toast">✓ {message}</div>}
  </main>
}
export default App
