package com.travel.cafe.repository;

import com.travel.cafe.data.CafeData;
import com.travel.cafe.data.CafeMenuData;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class CafeRepository {

    private static final String FIND_ALL_LOCATED_SQL =
            """
            SELECT
                id,
                kakao_place_id,
                cafe_name,
                category,
                phone,
                address,
                road_address,
                latitude,
                longitude,
                place_url,
                representative_image_url,
                rating,
                review_count,
                business_hours,
                summary,
                tags,
                facilities,
                last_scraped_at,
                last_scrape_status,
                created_at,
                updated_at
            FROM cafes
            WHERE latitude IS NOT NULL
              AND longitude IS NOT NULL
            """;


    private static final String FIND_BY_ID_SQL =
            """
            SELECT
                id,
                kakao_place_id,
                cafe_name,
                category,
                phone,
                address,
                road_address,
                latitude,
                longitude,
                place_url,
                representative_image_url,
                rating,
                review_count,
                business_hours,
                summary,
                tags,
                facilities,
                last_scraped_at,
                last_scrape_status,
                created_at,
                updated_at
            FROM cafes
            WHERE id = :cafeId
            LIMIT 1
            """;

    private static final String FIND_MENUS_SQL =
            """
            SELECT
                id,
                cafe_id,
                menu_name,
                description,
                image_url,
                current_price,
                is_recommended,
                menu_tags,
                last_seen_at,
                created_at,
                updated_at
            FROM cafe_menus
            WHERE cafe_id IN (:cafeIds)
              AND is_active = 1
            ORDER BY
                cafe_id ASC,
                is_recommended DESC,
                id ASC
            """;

    private final NamedParameterJdbcTemplate jdbcTemplate;

    public CafeRepository(
            NamedParameterJdbcTemplate jdbcTemplate
    ) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<CafeData> findAllLocated() {

        return jdbcTemplate.query(
                FIND_ALL_LOCATED_SQL,
                Map.of(),
                CAFE_ROW_MAPPER
        );
    }


    public CafeData findById(
            Long cafeId
    ) {

        MapSqlParameterSource params =
                new MapSqlParameterSource()
                        .addValue(
                                "cafeId",
                                cafeId
                        );

        List<CafeData> cafes =
                jdbcTemplate.query(
                        FIND_BY_ID_SQL,
                        params,
                        CAFE_ROW_MAPPER
                );

        return cafes.isEmpty()
                ? null
                : cafes.get(0);
    }

    public Map<Long, List<CafeMenuData>> findMenusByCafeIds(
            Collection<Long> cafeIds
    ) {

        if (cafeIds == null || cafeIds.isEmpty()) {
            return Map.of();
        }

        MapSqlParameterSource params =
                new MapSqlParameterSource()
                        .addValue(
                                "cafeIds",
                                cafeIds
                        );

        List<CafeMenuData> menus =
                jdbcTemplate.query(
                        FIND_MENUS_SQL,
                        params,
                        MENU_ROW_MAPPER
                );

        Map<Long, List<CafeMenuData>> result =
                new HashMap<>();

        for (CafeMenuData menu : menus) {

            result.computeIfAbsent(
                    menu.cafeId(),
                    key -> new ArrayList<>()
            ).add(menu);
        }

        return result;
    }

    private static final RowMapper<CafeData>
            CAFE_ROW_MAPPER =
            (rs, rowNum) ->
                    new CafeData(
                            nullableLong(rs, "id"),
                            rs.getString("kakao_place_id"),
                            rs.getString("cafe_name"),
                            rs.getString("category"),
                            rs.getString("phone"),
                            rs.getString("address"),
                            rs.getString("road_address"),
                            nullableDouble(rs, "latitude"),
                            nullableDouble(rs, "longitude"),
                            rs.getString("place_url"),
                            rs.getString("representative_image_url"),
                            nullableDouble(rs, "rating"),
                            nullableInteger(rs, "review_count"),
                            rs.getString("business_hours"),
                            rs.getString("summary"),
                            rs.getString("tags"),
                            rs.getString("facilities"),
                            nullableDateTime(
                                    rs,
                                    "last_scraped_at"
                            ),
                            rs.getString(
                                    "last_scrape_status"
                            ),
                            nullableDateTime(
                                    rs,
                                    "created_at"
                            ),
                            nullableDateTime(
                                    rs,
                                    "updated_at"
                            )
                    );

    private static final RowMapper<CafeMenuData>
            MENU_ROW_MAPPER =
            (rs, rowNum) ->
                    new CafeMenuData(
                            nullableLong(rs, "id"),
                            nullableLong(
                                    rs,
                                    "cafe_id"
                            ),
                            rs.getString("menu_name"),
                            rs.getString("description"),
                            rs.getString("image_url"),
                            nullableInteger(
                                    rs,
                                    "current_price"
                            ),
                            rs.getBoolean(
                                    "is_recommended"
                            ),
                            rs.getString("menu_tags"),
                            nullableDateTime(
                                    rs,
                                    "last_seen_at"
                            ),
                            nullableDateTime(
                                    rs,
                                    "created_at"
                            ),
                            nullableDateTime(
                                    rs,
                                    "updated_at"
                            )
                    );

    private static Long nullableLong(
            ResultSet rs,
            String column
    ) throws SQLException {

        Number value =
                (Number) rs.getObject(column);

        return value == null
                ? null
                : value.longValue();
    }

    private static Integer nullableInteger(
            ResultSet rs,
            String column
    ) throws SQLException {

        Number value =
                (Number) rs.getObject(column);

        return value == null
                ? null
                : value.intValue();
    }

    private static Double nullableDouble(
            ResultSet rs,
            String column
    ) throws SQLException {

        Number value =
                (Number) rs.getObject(column);

        return value == null
                ? null
                : value.doubleValue();
    }

    private static java.time.LocalDateTime
    nullableDateTime(
            ResultSet rs,
            String column
    ) throws SQLException {

        Timestamp timestamp =
                rs.getTimestamp(column);

        return timestamp == null
                ? null
                : timestamp.toLocalDateTime();
    }
}